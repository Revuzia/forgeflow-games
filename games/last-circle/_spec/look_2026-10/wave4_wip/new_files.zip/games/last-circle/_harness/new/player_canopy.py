#!/usr/bin/env python
"""player_canopy - P2.6 ram-air canopy replaces the dome (lane PLAYER, wave 4).

SESSION A (the shipped assets): a standard match, a REAL Space press deploys the human's canopy during the glide.
  * W._playerProbe.canopy(): state "loaded", 1700-1800 triangles per canopy, 20 line segments, span ~4.5 m
  * the actors group still holds exactly ONE actor-chute InstancedMesh and ONE actor-chute-lines LineSegments, the chute material still
    carries vertexColors + the lcChuteGore program key, and the canopy geometry has a colour attribute whose red channel is a 0/1 mask
  * every deployed canopy is drawn by that one mesh (count == deployed chutes) and the line buffer matches (draw range = chutes x 40 vertices)
  * 0 console / page / window errors, 0 failed requests, 0 shader errors, 0 [rig] lines
  * four screenshots of the human's canopy (game camera, side, front-below, top) saved to _shots (or --shots)
SESSION B (fallback): canopy.json answers 404 -> state "absent", the dome is still in use (a few hundred triangles), the match loads and plays,
  exactly ONE failed request (the json), 0 page / window errors.
Exit 0 pass / 1 fail / 2 could-not-judge.
    python _harness/new/player_canopy.py --isolate
"""
from __future__ import annotations

import argparse
import base64
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import common as C  # noqa: E402
import player_lib as PL  # noqa: E402

STRUCT_JS = r"""() => {
  const W = window.__LC__.W, P = W._playerProbe;
  const g = W.group('actors');
  const meshes = [], lines = [];
  g.traverse((o) => { if (o.name === 'actor-chute') meshes.push(o); if (o.name === 'actor-chute-lines') lines.push(o); });
  const m = meshes[0], l = lines[0];
  const col = m && m.geometry.attributes.color;
  let mask01 = null;
  if (col) { let lo = 1e9, hi = -1e9, mid = 0; for (let i = 0; i < col.count; i++) { const r = col.getX(i); lo = Math.min(lo, r); hi = Math.max(hi, r); if (r > 0.02 && r < 0.98) mid++; } mask01 = { lo, hi, fractional: mid, verts: col.count }; }
  const deployed = W.actors.filter((a) => a.chute).length;
  return {
    canopy: P.canopy(), instancedMeshes: meshes.length, lineSegmentsObjs: lines.length,
    meshIsInstanced: !!(m && m.isInstancedMesh), lineIsSegments: !!(l && l.isLineSegments),
    vertexColors: !!(m && m.material.vertexColors), progKey: m && m.material.customProgramCacheKey ? m.material.customProgramCacheKey() : null,
    meshCount: m ? m.count : null, deployed, lineDrawRange: l ? l.geometry.drawRange.count : null,
    triangles: m && m.geometry.index ? m.geometry.index.count / 3 : null, vertsPerMesh: m ? m.geometry.attributes.position.count : null,
    attrs: m ? Object.keys(m.geometry.attributes) : null, mask01,
  };
}"""

VIEWS_JS = r"""([name, dist, yawOff, pitch, fov]) => {
  const W = window.__LC__.W, k = W.kernel, cam = W.camera, p = W.player;
  const c = p.obj.position;
  const cx = c.x, cy = c.y + 3.2, cz = c.z;           // the canopy centre (3.2 m above the feet)
  const base = p.obj.rotation.y;                      // the body's facing (the canopy's nose points the same way)
  const ang = base + yawOff;
  cam.fov = fov || 50; cam.updateProjectionMatrix();
  cam.position.set(cx + Math.sin(ang) * dist, cy + dist * Math.sin(pitch), cz + Math.cos(ang) * dist * Math.cos(pitch));
  cam.lookAt(cx, cy - 0.7, cz); cam.updateMatrixWorld(true);
  if (k.composer) k.composer.render(0.016); else k.renderer.render(k.scene, cam);
  return k.renderer.domElement.toDataURL('image/png');
}"""


def run_session_a(args, v):
    with C.Session(args, "player_canopy_A") as s:
        PL.overlay(s, args)
        PL.served_note(v, args)
        s.boot()
        r = s.start_match("standard", args.seed, args.map)
        v.info("match", r)
        s.freeze_loop()
        s.step_frames(20, 1 / 60, render=False)
        # a REAL Space deploys the human's canopy (player.js toggles on the keydown while gliding)
        s.page.keyboard.press("Space")
        s.step_frames(60, 1 / 60, render=False)
        for _ in range(3):
            if s.js("() => !!window.__LC__.W.player.chute"):
                break
            s.page.keyboard.press("Space")
            s.step_frames(30, 1 / 60, render=False)
        s.step_frames(30, 1 / 60, render=True)
        st = s.js(STRUCT_JS)
        v.info("structure", st)
        cn = st["canopy"]
        v.check("canopy state is loaded", cn.get("state") == "loaded", cn)
        v.check("canopy triangles 1700-1800 per instance, 20 line segments", cn.get("state") == "loaded" and 1700 <= st["triangles"] <= 1800 and cn["lines"] == 20,
                {"triangles": st["triangles"], "lines": cn.get("lines"), "span": cn.get("span")})
        v.check("still ONE InstancedMesh and ONE LineSegments for every canopy", st["instancedMeshes"] == 1 and st["lineSegmentsObjs"] == 1 and st["meshIsInstanced"] and st["lineIsSegments"],
                {k: st[k] for k in ("instancedMeshes", "lineSegmentsObjs", "meshIsInstanced", "lineIsSegments")})
        v.check("chute material unchanged: vertexColors + the lcChuteGore program key", st["vertexColors"] and st["progKey"] == "lcChuteGore", {"vc": st["vertexColors"], "key": st["progKey"]})
        mk = st["mask01"]
        v.check("canopy colour attribute carries the gore mask (red 0..1, both ends present)", bool(mk) and mk["lo"] <= 0.02 and mk["hi"] >= 0.98, mk)
        v.check("every deployed canopy is one instance and the line batch matches (draw range = chutes x 40 vertices)",
                st["deployed"] >= 1 and st["meshCount"] == st["deployed"] and st["lineDrawRange"] == st["deployed"] * 40,
                {k: st[k] for k in ("deployed", "meshCount", "lineDrawRange")})
        shots = args.shots or C.SHOTS
        os.makedirs(shots, exist_ok=True)
        for name, dist, yaw, pitch, fov in (("rear_above", 13.0, 0.0, 0.5, 50), ("side", 13.0, 1.5708, 0.1, 50), ("front_below", 13.0, 3.1416, -0.35, 50), ("top", 14.0, 0.0, 1.3, 50)):
            url = s.js(VIEWS_JS, [name, dist, yaw, pitch, fov])
            pth = os.path.join(shots, "player_canopy_%s.png" % name)
            with open(pth, "wb") as f:
                f.write(base64.b64decode(url.split(",", 1)[1]))
            v.info("shot", pth)
        d = s.diagnostics()
        v.data["diagnosticsA"] = d
        C.print_diagnostics(d)
        v.check("A: 0 console errors", not d["consoleErrors"], d["consoleErrors"][:5])
        v.check("A: 0 page / window errors", not (d["pageErrors"] or d["windowErrors"]), (d["pageErrors"] + d["windowErrors"])[:5])
        v.check("A: 0 failed requests", not d["failedRequests"], d["failedRequests"][:8])
        v.check("A: 0 shader errors, 0 [rig] lines", not d["shader"] and not d["rigWarnings"], (d["shader"] + d["rigWarnings"])[:4])


def run_session_b(args, v):
    with C.Session(args, "player_canopy_B") as s:
        PL.overlay(s, args)
        s.start_blocked = True

        def deny(route):
            route.fulfill(status=404, body="Not found", headers={"Cache-Control": "no-store"})

        s.context.route(lambda url: "/assets/props/canopy." in url, deny)
        s.boot()
        s.start_match("standard", args.seed, args.map)
        s.freeze_loop()
        s.step_frames(20, 1 / 60, render=False)
        s.page.keyboard.press("Space")
        s.step_frames(60, 1 / 60, render=True)
        st = s.js(STRUCT_JS)
        cn = st["canopy"]
        v.info("B structure", st)
        v.check("B: canopy.json 404 -> state absent and the dome is still the canopy (< 400 triangles, 6 line segments)",
                cn.get("state") == "absent" and st["triangles"] is not None and st["triangles"] < 400 and st["lineDrawRange"] == st["deployed"] * 12,
                {"state": cn.get("state"), "triangles": st["triangles"], "deployed": st["deployed"], "lineDrawRange": st["lineDrawRange"]})
        d = s.diagnostics()
        v.data["diagnosticsB"] = d
        v.check("B: exactly ONE failed request (the canopy.json probe)", len(d["failedRequests"]) == 1 and "canopy.json" in d["failedRequests"][0], d["failedRequests"][:4])
        v.check("B: 0 page / window errors, 0 shader errors", not (d["pageErrors"] or d["windowErrors"] or d["shader"]), (d["pageErrors"] + d["windowErrors"] + d["shader"])[:4])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    C.add_common_args(ap)
    PL.add_args(ap)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--map", default="isla_viva", choices=C.MAPS)
    ap.add_argument("--shots", default=None)
    ap.add_argument("--skip-fallback", action="store_true")
    args = ap.parse_args()
    PL.prepare(args)

    def body(v):
        run_session_a(args, v)
        if not args.skip_fallback:
            run_session_b(args, v)
    return C.run_gate("player_canopy", body, args)


if __name__ == "__main__":
    sys.exit(main())
