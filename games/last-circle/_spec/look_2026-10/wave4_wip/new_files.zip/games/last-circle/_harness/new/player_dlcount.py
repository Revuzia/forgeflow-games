#!/usr/bin/env python
"""player_dlcount - P1.1 every animation clip is downloaded ONCE (lane PLAYER, wave 4).

A dlprobe-style count of what the page really fetches under assets/chars/ from a cold boot to the lobby (the browser's own
PerformanceResourceTiming entries: URL, decodedBodySize). Two runs in one gate:

  BEFORE  git HEAD with NONE of this lane's files (the old path: <skin>_<clip>.glb x 5 skins)
  AFTER   the build under test (with --isolate: HEAD + this lane's files from the working copy / --overlay-root)

Asserts (counts and bytes, never milliseconds):
  * BEFORE fetched 85 per-skin clip files (17 clips x 5 skins), AFTER fetched 0 (every per-skin clip request is gone)
  * AFTER fetched each shared assets/chars/clips/<clip>.glb exactly once (15 clips + 7 death falls = 22, none twice)
  * clip bytes AFTER <= 25 % of BEFORE (the plan: 8.83 MB -> ~0.7 MB)
  * base meshes and LOD1 bodies unchanged: 5 + 5 requests, same bytes in both runs
  * W._playerProbe.clips() reports mode "shared" with 22 requests
  * 0 console / page / window errors, 0 failed requests (a 404 on a shared file would be a failed request), 0 [rig] lines
Exit 0 pass / 1 fail / 2 could-not-judge.
    python _harness/new/player_dlcount.py --isolate [--no-before]
"""
from __future__ import annotations

import argparse
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import common as C  # noqa: E402
import player_lib as PL  # noqa: E402

SKINS = ["soldier", "athlete", "wraith", "juggernaut", "viper"]

ENTRIES_JS = r"""() => performance.getEntriesByType('resource')
  .filter((e) => e.name.indexOf('/assets/chars/') >= 0)
  .map((e) => ({ url: e.name.split('?')[0], body: e.decodedBodySize || 0, enc: e.encodedBodySize || 0, transfer: e.transferSize || 0 }))"""


def classify(entries):
    out = {"perSkinClips": [], "shared": [], "bases": [], "lod1": [], "other": []}
    for e in entries:
        u = e["url"]
        m = re.search(r"/assets/chars/clips/([^/]+)\.glb$", u)
        if m:
            out["shared"].append((m.group(1), e["body"]))
            continue
        m = re.search(r"/assets/chars/meshy/([a-z]+)(?:_([a-z0-9_]+))?\.glb$", u)
        if not m:
            out["other"].append((u, e["body"]))
            continue
        skin, rest = m.group(1), m.group(2)
        if skin not in SKINS:
            out["other"].append((u, e["body"]))
        elif rest is None:
            out["bases"].append((skin, e["body"]))
        elif rest == "lod1":
            out["lod1"].append((skin, e["body"]))
        else:
            out["perSkinClips"].append((skin + "_" + rest, e["body"]))
    return out


def run_once(args, v, label, isolate_overlay):
    """Boot -> startMatch (the lobby); returns (classified entries, diagnostics, probe)."""
    a2 = argparse.Namespace(**vars(args))
    a2.isolate = isolate_overlay
    with C.Session(a2, "player_dlcount_" + label) as s:
        PL.overlay(s, a2)
        s.boot()
        r = s.start_match("standard", args.seed, args.map, enter=False)
        v.info("%s match loaded" % label, r)
        s.sleep(1.0)
        ent = s.js(ENTRIES_JS)
        probe = s.safe_js("() => { const p = window.__LC__.W._playerProbe; return p ? p.clips() : null; }")
        d = s.diagnostics()
    return classify(ent), d, probe


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    C.add_common_args(ap)
    PL.add_args(ap)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--map", default="isla_viva", choices=C.MAPS)
    ap.add_argument("--no-before", action="store_true", help="skip the BEFORE run (the HEAD build); the ratio rows become could-not-judge")
    args = ap.parse_args()
    PL.prepare(args)
    if not args.isolate:
        # without --isolate there is no "before" build to serve: the whole working copy is the AFTER
        args.no_before = True

    def body(v):
        before = None
        if not args.no_before:
            # BEFORE = git HEAD with no overlay at all
            args_b = argparse.Namespace(**vars(args))
            args_b.isolate = False
            args_b.rev = "HEAD"
            args_b.disk = True
            before, db, _ = run_once(args_b, v, "BEFORE", False)
            v.info("BEFORE counts", {"perSkinClipRequests": len(before["perSkinClips"]), "perSkinClipBytes": sum(b for _, b in before["perSkinClips"]),
                                     "shared": len(before["shared"]), "bases": len(before["bases"]), "lod1": len(before["lod1"])})
        after, da, probe = run_once(args, v, "AFTER", bool(args.isolate))
        sh_names = [n for n, _ in after["shared"]]
        v.info("AFTER counts", {"perSkinClipRequests": len(after["perSkinClips"]), "shared": len(after["shared"]), "sharedBytes": sum(b for _, b in after["shared"]),
                                "bases": len(after["bases"]), "lod1": len(after["lod1"]), "probe": probe})
        v.data["after"] = {k: [list(x) for x in vv] for k, vv in after.items()}
        if before is not None:
            v.data["before"] = {k: [list(x) for x in vv] for k, vv in before.items()}
            v.check("BEFORE: the old path fetched 17 clips x 5 skins = 85 per-skin clip files", len(before["perSkinClips"]) == 85,
                    {"n": len(before["perSkinClips"]), "bytes": sum(b for _, b in before["perSkinClips"])})
            old_b = sum(b for _, b in before["perSkinClips"])
            new_b = sum(b for _, b in after["shared"]) + sum(b for _, b in after["perSkinClips"])
            v.check("clip bytes AFTER <= 25 %% of BEFORE (%d -> %d B)" % (old_b, new_b), old_b > 0 and new_b <= 0.25 * old_b,
                    {"before": old_b, "after": new_b, "ratio": round(new_b / max(1, old_b), 3)})
            v.check("base meshes + LOD1 bodies unchanged (5 + 5 requests, same bytes)",
                    len(after["bases"]) == 5 and len(after["lod1"]) == 5 and sorted(after["bases"]) == sorted(before["bases"]) and sorted(after["lod1"]) == sorted(before["lod1"]),
                    {"bases": [len(before["bases"]), len(after["bases"])], "lod1": [len(before["lod1"]), len(after["lod1"])]})
        else:
            v.cnj("BEFORE/AFTER ratio rows", "no BEFORE run (--no-before, or no --isolate so there is no HEAD build to compare)")
        v.check("AFTER: 0 per-skin clip requests", len(after["perSkinClips"]) == 0, {"n": len(after["perSkinClips"]), "first": after["perSkinClips"][:4]})
        v.check("AFTER: each shared clip fetched exactly once, 22 files (15 clips + 7 death falls)",
                len(sh_names) == 22 and len(set(sh_names)) == 22, {"n": len(sh_names), "unique": len(set(sh_names)), "dupes": sorted({n for n in sh_names if sh_names.count(n) > 1})})
        v.check("AFTER: no death2 / death3 requested (the Meshy falls are gone)", not any(n in ("death2", "death3") for n in sh_names), sh_names)
        v.check("W._playerProbe.clips(): mode shared, 22 requests, 22 loaded", bool(probe) and probe.get("mode") == "shared" and probe.get("requests") == 22 and probe.get("loaded") == 22, probe)
        for lab, d in (("AFTER", da),) + ((("BEFORE", db),) if before is not None else ()):
            C.print_diagnostics(d)
        v.check("AFTER: 0 console errors", not da["consoleErrors"], da["consoleErrors"][:5])
        v.check("AFTER: 0 page / window errors", not (da["pageErrors"] or da["windowErrors"]), (da["pageErrors"] + da["windowErrors"])[:5])
        v.check("AFTER: 0 failed requests", not da["failedRequests"], da["failedRequests"][:8])
        v.check("AFTER: 0 shader errors, 0 [rig] lines", not da["shader"] and not da["rigWarnings"], (da["shader"] + da["rigWarnings"])[:4])
    return C.run_gate("player_dlcount", body, args)


if __name__ == "__main__":
    sys.exit(main())
