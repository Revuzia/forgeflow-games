#!/usr/bin/env python
"""orch_lowpost - ORCH lane (Wave 4): the LOW tier draws straight to the canvas, and the post route survives tier changes.

    python _harness/new/orch_lowpost.py --disk                 # whole working tree
    python _harness/new/orch_lowpost.py --disk --isolate       # git HEAD for every file except ffg_royale3d.js (other lanes' edits out)
    python _harness/new/orch_lowpost.py --disk --leak          # + 3 back-to-back matches on low, textures/geometries flat

What it proves (exit 0 pass / 1 fail / 2 could-not-judge; same convention as every other gate):
  low from boot       a stored tier of 'low' boots to kernel.composer.isDirectPost (hud.js:823 must NOT rebuild one), W._gfx.post
                      === 'direct', no UnrealBloomPass was ever allocated (kernel.bloom undefined)
  sky chunks          every non-raw ShaderMaterial in the scene (both sky domes) ends with the output chunks, menu AND match,
                      so the raw-linear sky never reaches the canvas
  warm-up             W._warm.post === 'direct' (the warm frame was drawn to the canvas), W._warm.by lists every provider; drop
                      frame 1 links 0 new programs on the direct route
  looks like composer the same stepped frame drawn through the composer (?lowpost=1, the pre-change behaviour) and straight to the
                      canvas: the SKY band and the whole frame stay within tolerance (the sky shader was the known risk)
  tier switches       low -> medium brings a REAL composer back (RenderPass, bloom, output pass), renders a non-black frame, and
                      medium -> low drops to direct again, 0 page errors
  0 console / page / window errors, 0 failed requests, 0 shader errors across all of it
The control (`?lowpost=1`) must report composer 'real' with the bloom pass off: that is the old low-tier behaviour, kept as the A/B arm.
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C  # noqa: E402

TIER_INIT = r"""(() => { try { const m = /[#&]h_tier=(low|medium|high)/.exec(location.hash || '');
  if (m) localStorage.setItem('lc_settings', JSON.stringify({ graphics: m[1] })); } catch (_) {} })();"""

PROBE_JS = r"""() => { const W = window.__LC__.W, k = W.kernel, r = k.renderer, c = k.composer;
  return { composer: c ? (c.isDirectPost ? 'direct' : 'real') : null,
           passes: c && c.passes ? c.passes.map((p) => p.constructor.name + (p.enabled === false ? '(off)' : '')) : null,
           bloomObject: !!k.bloom, bloomEnabled: k.bloom ? !!k.bloom.enabled : null, bloomStrength: k.bloom ? +k.bloom.strength.toFixed(3) : null,
           post: W._gfx ? W._gfx.post : null, tier: W._gfx ? W._gfx.tier : null, phase: W.phase,
           textures: r.info.memory.textures, geometries: r.info.memory.geometries, programs: r.info.programs ? r.info.programs.length : -1,
           toneMapping: r.toneMapping, exposure: r.toneMappingExposure, pr: r.getPixelRatio() }; }"""

SHADERS_JS = r"""() => { const W = window.__LC__.W; const out = [], seen = new Set();
  W.scene.traverse((o) => { const m = o.material; if (!m) return;
    for (const mm of (Array.isArray(m) ? m : [m])) { if (!mm || !mm.isShaderMaterial || seen.has(mm)) continue; seen.add(mm);
      out.push({ obj: o.name || o.type, raw: !!mm.isRawShaderMaterial,
                 chunks: /tonemapping_fragment|colorspace_fragment|linearToOutputTexel/.test(mm.fragmentShader || '') }); } });
  return out; }"""

WARM_JS = r"""() => { const W = window.__LC__.W; return W._warm || null; }"""
# level the view (input.pitch > 0 = looking up) so the upper half of the frame is SKY, whatever the drop pose was
HORIZON_JS = r"""(pitch) => { const W = window.__LC__.W, p = W.player; p.input.pitch = pitch; p.pitch = pitch; return { pitch: p.input.pitch, gliding: !!p.gliding, y: +p.pos.y.toFixed(1) }; }"""
PROGRAMS_JS = r"""() => { const i = window.__LC__.W.kernel.renderer.info; return i.programs ? i.programs.length : -1; }"""
APPLY_JS = r"""(tier) => { const W = window.__LC__.W; W.settings.graphics = tier; W.applyGraphics(tier); return W._gfx; }"""
TEX_JS = r"""() => { const i = window.__LC__.W.kernel.renderer.info; return { textures: i.memory.textures, geometries: i.memory.geometries, programs: i.programs ? i.programs.length : -1 }; }"""


def head_override(session, rel_suffix="/runtime/3d/ffg_royale3d.js"):
    """--isolate: the session serves git HEAD (args.rev) for everything; route ONLY the orchestrator to the working copy."""
    path = os.path.join(C.ROOT, "runtime", "3d", "ffg_royale3d.js")
    with open(path, "rb") as f:
        body = f.read()

    def pred(url):
        return url.split("?")[0].endswith(rel_suffix)

    def handler(route):
        route.fulfill(status=200, body=body, headers={"Content-Type": "text/javascript; charset=utf-8", "Cache-Control": "no-store",
                                                      "Access-Control-Allow-Origin": "*"})
    session.disk.overrides.append((pred, handler))


def url_for(base, tier, lowpost=False, n=0):
    q = "?" if "?" not in base else "&"
    return "%s%slc=%d%s#h_tier=%s" % (base, q, n, "&lowpost=1" if lowpost else "", tier)


def img_stats(path):
    import numpy as np
    from PIL import Image
    im = np.asarray(Image.open(path).convert("RGB")).astype(np.float32)
    h, w = im.shape[:2]
    lum = float(im.mean())
    return im, {"w": w, "h": h, "meanRGB": [round(float(x), 2) for x in im.reshape(-1, 3).mean(0)], "meanLum": round(lum, 2)}


def compare(a_path, b_path):
    import numpy as np
    a, sa = img_stats(a_path)
    b, sb = img_stats(b_path)
    if a.shape != b.shape:
        return {"error": "shape %s vs %s" % (a.shape, b.shape), "a": sa, "b": sb}
    d = np.abs(a - b)
    h, w = a.shape[:2]
    # 8 x 6 grid of mean colour differences; row 0 is the top strip (the sky wherever the horizon is below it)
    gx, gy = 8, 6
    cells = []
    for j in range(gy):
        row = []
        for i in range(gx):
            ca = a[j * h // gy:(j + 1) * h // gy, i * w // gx:(i + 1) * w // gx].reshape(-1, 3).mean(0)
            cb = b[j * h // gy:(j + 1) * h // gy, i * w // gx:(i + 1) * w // gx].reshape(-1, 3).mean(0)
            row.append(round(float(np.abs(ca - cb).max()), 1))
        cells.append(row)
    top = a[: h // 8]
    topb = b[: h // 8]
    return {"a": sa, "b": sb, "meanAbsDiff": round(float(d.mean()), 2), "p99AbsDiff": round(float(np.percentile(d, 99)), 1),
            "topStripMeanDiff": [round(float(x), 2) for x in np.abs(top.reshape(-1, 3).mean(0) - topb.reshape(-1, 3).mean(0))],
            "gridMaxChannelDiff": cells, "gridMax": max(max(r) for r in cells)}


def drop_frame_one(s, v, label):
    """Freeze the loop, press Enter into the drop, count programs around ONE stepped rendered frame (framecheck's method)."""
    s.freeze_loop()
    before = s.js(PROGRAMS_JS)
    s.page.keyboard.press("Enter")
    ok = s.wait_js("() => ['drop', 'match'].includes(window.__LC__.W.phase)", 8, 0.1)
    if ok is None:
        s.page.keyboard.press("Enter")
        ok = s.wait_js("() => ['drop', 'match'].includes(window.__LC__.W.phase)", 8, 0.1)
    mid = s.js(PROGRAMS_JS)
    s.step_frames(1, 1 / 60, render=True)
    after = s.js(PROGRAMS_JS)
    return {"phaseReached": ok is not None, "programsBeforeEnter": before, "programsAtDropStart": mid, "programsAfterFrame1": after,
            "newOnDropFrame1": after - mid}


def one_match_load(s, seed, map_id):
    return s.start_match("standard", seed, map_id, enter=False)


def run_arm(args, v, tier, lowpost, shot, tag):
    """Boot at a stored tier, record the menu, load a standard match, take drop frame 1 and a fixed-pose capture."""
    out = {"tag": tag}
    with C.Session(args, "orch_lowpost_" + tag, init_scripts=[TIER_INIT]) as s:
        if getattr(args, "isolate", False):
            head_override(s)
        s.boot(url_for(args.base, tier, lowpost, 1))
        s.freeze_loop()
        out["menu"] = s.js(PROBE_JS)
        out["menuShaders"] = s.js(SHADERS_JS)
        s.step_frames(5, 1 / 60, render=True)
        out["menuAfterFrames"] = s.js(PROBE_JS)
        s.thaw_loop()
        out["load"] = one_match_load(s, args.seed, args.map)
        out["lobby"] = s.js(PROBE_JS)
        out["warm"] = s.js(WARM_JS)
        out["matchShaders"] = s.js(SHADERS_JS)
        out["drop1"] = drop_frame_one(s, v, tag)
        s.step_frames(args.frames, 1 / 60, render=True)
        out["atCapture"] = s.js(PROBE_JS)
        s.canvas_png(shot)
        out["shot"] = shot
        out["horizonPose"] = s.js(HORIZON_JS, args.horizon_pitch)
        s.step_frames(6, 1 / 60, render=True)
        hshot = shot.replace(".png", "_horizon.png")
        s.canvas_png(hshot)
        out["horizonShot"] = hshot
        if tag == "direct":
            # tier switches in the live session: low -> medium (real composer) -> low (direct again)
            sw = {}
            sw["toMedium"] = s.js(APPLY_JS, "medium")
            s.step_frames(8, 1 / 60, render=True)
            sw["medium"] = s.js(PROBE_JS)
            medium_png = shot.replace(".png", "_medium.png")
            s.canvas_png(medium_png)
            sw["mediumShot"] = img_stats(medium_png)[1]
            sw["toLow"] = s.js(APPLY_JS, "low")
            s.step_frames(8, 1 / 60, render=True)
            sw["lowAgain"] = s.js(PROBE_JS)
            low_png = shot.replace(".png", "_lowagain.png")
            s.canvas_png(low_png)
            sw["lowAgainShot"] = img_stats(low_png)[1]
            out["switch"] = sw
        out["diag"] = s.diagnostics()
    return out


def leak_part(args, v):
    """3 back-to-back matches on low: lobby textures/geometries of matches 2 and 3 within +-5 of match 1 (leaktest's bar)."""
    rows = []
    with C.Session(args, "orch_lowpost_leak", init_scripts=[TIER_INIT]) as s:
        if getattr(args, "isolate", False):
            head_override(s)
        s.boot(url_for(args.base, "low", False, 9))
        for i in range(3):
            s.thaw_loop() if i else None
            s.start_match("standard", 4242, "ashgrid", enter=False)
            s.freeze_loop()
            s.step_frames(3, 1 / 60, render=True)
            rows.append(s.js(TEX_JS))
            s.thaw_loop()
        d = s.diagnostics()
    return rows, d


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    C.add_common_args(ap)
    ap.add_argument("--isolate", action="store_true", help="serve git HEAD for every file except the working-copy ffg_royale3d.js")
    ap.add_argument("--leak", action="store_true", help="also run 3 back-to-back matches on low (textures/geometries flat)")
    ap.add_argument("--map", default="isla_viva")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--frames", type=int, default=24, help="stepped rendered frames before the fixed-pose capture")
    ap.add_argument("--horizon-pitch", type=float, default=0.12, help="input.pitch (radians, >0 = up) of the horizon capture")
    ap.add_argument("--sky-tol", type=float, default=14.0, help="max mean abs colour difference (0-255) of the top strip, direct vs composer")
    ap.add_argument("--frame-tol", type=float, default=14.0, help="max mean abs difference (0-255) of the whole frame, direct vs composer")
    args = ap.parse_args()
    if args.isolate and not args.rev:
        args.rev = "HEAD"

    shots = os.path.join(C.HERE, "_shots", "orch")
    os.makedirs(shots, exist_ok=True)

    def body(v):
        direct = run_arm(args, v, "low", False, os.path.join(shots, "low_direct.png"), "direct")
        v.data["direct"] = direct
        # ---- low from boot
        m = direct["menu"]
        v.check("low from boot: kernel.composer is the direct route (hud.js did not rebuild a composer)", m["composer"] == "direct" and m["post"] == "direct", m,
                expect="composer 'direct', W._gfx.post 'direct'")
        v.check("low from boot: no bloom pass was ever allocated", not m["bloomObject"], {"bloomObject": m["bloomObject"], "textures": m["textures"]},
                expect="kernel.bloom undefined (no composer, no half-float targets)")
        mf = direct["menuAfterFrames"]
        v.check("menu frames render on the direct route without a throw", mf["composer"] == "direct" and mf["tier"] == "low", mf)
        bad_menu = [x for x in direct["menuShaders"] if not x["raw"] and not x["chunks"]]
        v.check("menu: every non-raw ShaderMaterial carries the output chunks (the sky dome included)",
                bool(direct["menuShaders"]) and not bad_menu, {"shaders": direct["menuShaders"], "without": bad_menu},
                expect=">= 1 ShaderMaterial, none without the chunks")
        # ---- match
        w = direct["warm"] or {}
        v.check("warm-up frame drawn on the direct route (W._warm.post)", w.get("post") == "direct", {"warm": w}, expect="'direct'")
        v.info("warm-up providers (W._warm.by) and program counts", {"by": w.get("by"), "programs": w.get("programs"), "extrasIn": w.get("extrasIn"), "ms": w.get("ms")})
        bad_match = [x for x in direct["matchShaders"] if not x["raw"] and not x["chunks"]]
        v.check("match: every non-raw ShaderMaterial carries the output chunks (the match sky included)",
                bool(direct["matchShaders"]) and not bad_match, {"shaders": direct["matchShaders"], "without": bad_match})
        d1 = direct["drop1"]
        if not d1["phaseReached"]:
            v.cnj("drop frame 1 on low: 0 new programs", "a real Enter did not reach the drop (%s)" % d1)
        else:
            v.check("drop frame 1 on low: 0 new programs", d1["newOnDropFrame1"] == 0, d1, expect="0 (the warm-up covered the canvas variant)")
        cap = direct["atCapture"]
        v.check("capture frame drawn on the direct route", cap["composer"] == "direct" and cap["tier"] == "low", cap)
        # ---- tier switches
        sw = direct["switch"]
        med = sw["medium"]
        v.check("low -> medium brings a REAL composer back (RenderPass, bloom, output pass)",
                med["composer"] == "real" and med["passes"] and len(med["passes"]) >= 3 and "UnrealBloomPass" in med["passes"] and med["bloomEnabled"] is True,
                {"switch": sw["toMedium"], "probe": med}, expect="composer 'real', passes [RenderPass, UnrealBloomPass, *OutputPass], bloom enabled")
        v.check("low -> medium renders a non-black frame", sw["mediumShot"]["meanLum"] > 20, sw["mediumShot"], expect="mean luminance > 20/255")
        la = sw["lowAgain"]
        v.check("medium -> low drops to the direct route again and renders a non-black frame",
                la["composer"] == "direct" and sw["lowAgainShot"]["meanLum"] > 20, {"probe": la, "shot": sw["lowAgainShot"]})
        v.info("bloom strength after the low -> medium switch (match look is 0.14)", med.get("bloomStrength"))
        # ---- control arm
        comp = run_arm(args, v, "low", True, os.path.join(shots, "low_composer.png"), "composer")
        v.data["composer"] = comp
        cm = comp["atCapture"]
        v.check("control (?lowpost=1): low keeps the REAL composer with the bloom pass off (the old behaviour)",
                cm["composer"] == "real" and cm["bloomEnabled"] is False and cm["post"] == "composer", cm,
                expect="composer 'real', bloom pass disabled")
        cmp_ = compare(direct["shot"], comp["shot"])
        v.data["compare"] = cmp_
        if "error" in cmp_:
            v.cnj("direct vs composer: same-pose frames comparable", cmp_["error"])
        else:
            v.info("direct vs composer, same stepped frame (information; see the PNGs in _shots/orch)", cmp_)
            v.check("direct vs composer: the sky band (top strip) matches within tolerance",
                    max(cmp_["topStripMeanDiff"]) <= args.sky_tol, {"topStripMeanDiff": cmp_["topStripMeanDiff"], "tol": args.sky_tol},
                    expect="<= %.0f / 255 per channel (raw-linear sky would be ~100+ darker)" % args.sky_tol)
            v.check("direct vs composer: whole-frame mean difference within tolerance",
                    cmp_["meanAbsDiff"] <= args.frame_tol, {"meanAbsDiff": cmp_["meanAbsDiff"], "p99": cmp_["p99AbsDiff"], "tol": args.frame_tol})
        hcmp = compare(direct["horizonShot"], comp["horizonShot"])
        v.data["compareHorizon"] = hcmp
        if "error" in hcmp:
            v.cnj("direct vs composer at the horizon: comparable", hcmp["error"])
        else:
            v.info("direct vs composer, horizon pose (information)", hcmp)
            v.check("horizon pose: the sky band (top strip) matches within tolerance",
                    max(hcmp["topStripMeanDiff"]) <= args.sky_tol, {"topStripMeanDiff": hcmp["topStripMeanDiff"], "tol": args.sky_tol,
                                                                   "a": hcmp["a"]["meanRGB"], "b": hcmp["b"]["meanRGB"]},
                    expect="<= %.0f / 255 per channel (a raw-linear sky is ~100+ darker)" % args.sky_tol)
            v.check("horizon pose: whole-frame mean difference within tolerance", hcmp["meanAbsDiff"] <= args.frame_tol,
                    {"meanAbsDiff": hcmp["meanAbsDiff"], "p99": hcmp["p99AbsDiff"], "tol": args.frame_tol})
        # ---- diagnostics for both sessions
        for name, arm in (("direct", direct), ("composer", comp)):
            probs = C.diag_problems(arm["diag"])
            v.check("%s arm: 0 console / page / window errors, 0 failed requests, 0 shader errors" % name, not probs, probs or "clean")
        if args.leak:
            rows, d = leak_part(args, v)
            v.data["leak"] = rows
            t0 = rows[0]
            ok = all(abs(r["textures"] - t0["textures"]) <= 5 and abs(r["geometries"] - t0["geometries"]) <= 5 for r in rows[1:])
            v.check("3 matches on low: textures + geometries of matches 2 and 3 within +-5 of match 1", ok, rows, expect="flat")
            probs = C.diag_problems(d)
            v.check("leak part: 0 errors", not probs, probs or "clean")

    return C.run_gate("orch_lowpost", body, args)


if __name__ == "__main__":
    sys.exit(main())
