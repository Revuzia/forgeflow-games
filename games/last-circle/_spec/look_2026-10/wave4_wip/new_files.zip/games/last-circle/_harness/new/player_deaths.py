#!/usr/bin/env python
"""player_deaths - P1.6 seven Mixamo death falls + the corpse timeline on SIM time (lane PLAYER, wave 4).

A standard match is loaded, the human lands (protected) and the kernel loop is frozen; frames are stepped (sim tick + mixers each).

  (1) NATURAL KILLS: bots fight on their own; the first 20 deaths after the landing are logged with the fall clip they got.
      >= 5 distinct falls among the 20, every fall is one of the seven (death2 / death3 never appear), and at the END of each clip
      the hips are <= 0.6 m above the ground (nobody stands back up).
  (2) pickDeath as a pure function over constructed hits: front / back / right body hits take death_front / death_back /
      death_right, headshots the head variants, a crouching headshot death_crouch_head, a mover can take death_walking; the pick is a
      pure function of (seed, victim, sim tick) - same inputs, same fall - and a side hit varies with the tick (seeded, never Math.random()).
  (3) THE FACING MATHS IS RIGHT: independent of the game's own formula, the real skeleton of 6 living bots is measured:
      the toes point along (sin b, cos b) and the right hand lies on the (-cos b, sin b) side, b = actor.obj.rotation.y.
  (4) CORPSE TIMELINE ON SIM TIME: (a) a real 3.6 s wait with NO frames stepped does not advance it (the old setTimeout(3000) did);
      (b) a pause during the sink freezes it exactly (y and _sinkT unchanged over 300 stepped frames), resume finishes it and the
      rig is freed; (c) hit-stop slows it (a 0.667 s hit-stop window advances _sinkT by 0.05-0.14 s, not 0.667).
  (5) 0 console / page / window errors, 0 failed requests, 0 shader errors, 0 [rig] lines.
Exit 0 pass / 1 fail / 2 could-not-judge.
    python _harness/new/player_deaths.py --isolate
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import common as C  # noqa: E402
import player_lib as PL  # noqa: E402

DEATHS = ["death_front", "death_front_head", "death_back", "death_back_head", "death_right", "death_crouch_head", "death_walking"]

NATURAL_JS = r"""([kills, maxFrames]) => {
  const Cn = window.__LC__, W = Cn.W;
  const seen = new Set(); for (const a of W.actors) if (!a.alive) seen.add(a.id);
  const rows = []; let frames = 0;
  const hipsOf = (a) => { let h = null; a.rig.scene.traverse((o) => { if (!h && o.isBone && /Hips$/.test(o.name)) h = o; }); return h; };
  const v = new W.camera.position.constructor();
  while (frames < maxFrames && (rows.length < kills || rows.some((r) => r.hipsEnd == null && !r.gone))) {
    Cn.stepFrames(6, 1 / 60, false); frames += 6;
    const p = W.player; if (p && p.alive) { p.hp = 100; p.shield = 100; }
    for (const a of W.actors) {
      if (a.alive || a.isDummy || a === W.player || seen.has(a.id) || rows.length >= kills) continue;
      seen.add(a.id);
      const lh = a.lastHit, cn = a.clips ? a.clips[a.anim] : null;
      const act = cn && a.rig.actions[cn];
      rows.push({ id: a.id, skin: a.skin, anim: a.anim, head: !!(lh && lh.isHead), crouch: !!a.crouching, byActor: !!(lh && lh.attackerId),
                  dur: act ? act.getClip().duration : null, hold: a._sinkHold, t: +W.t.toFixed(2), hipsEnd: null, gone: false });
    }
    for (const r of rows) {
      if (r.hipsEnd != null || r.gone) continue;
      const a = W.actorById.get(r.id);
      if (!a || !a.obj.parent) { r.gone = true; continue; }
      if (r.dur != null && a._sinkT >= r.dur + 0.05) {
        const h = hipsOf(a); a.obj.updateMatrixWorld(true);
        if (h) { h.getWorldPosition(v); r.hipsEnd = +(v.y - a._sinkY0).toFixed(3); } else r.gone = true;
      }
    }
  }
  return { rows, frames, w_t: +W.t.toFixed(1) };
}"""

FORCED_JS = r"""() => {
  const W = window.__LC__.W, P = W._playerProbe;
  const bots = W.actors.filter((a) => a.alive && !a.isDummy && a !== W.player && a.rig);
  if (bots.length < 2) return { error: 'need 2 live bots' };
  const vic = bots[0], att = bots[1];
  const save = { pos: vic.pos.clone(), vel: vic.vel.clone(), lh: vic.lastHit, crouch: vic.crouching, rot: vic.obj.rotation.y, apos: att.pos.clone(), tick: W.simTick };
  const out = { cases: [], det: null, vary: null, walk: null, avail: Object.keys(vic.clips).filter((k) => /^death/.test(k) && vic.clips[k]) };
  const place = (ang, head, crouch, moving) => {
    // victim at origin facing b; attacker 8 m away at an angle measured from its forward (0 = front, pi = back, +pi/2 = its right)
    const b = 0.7; vic.obj.rotation.y = b; vic.pos.set(100, 0, 100); vic.vel.set(moving ? 5 : 0, 0, 0); vic.crouching = !!crouch; vic.onGround = true; vic.swimming = false;
    const fx = Math.sin(b), fz = Math.cos(b), rx = -Math.cos(b), rz = Math.sin(b);
    att.pos.set(vic.pos.x + 8 * (Math.cos(ang) * fx + Math.sin(ang) * rx), 0, vic.pos.z + 8 * (Math.cos(ang) * fz + Math.sin(ang) * rz));
    vic.lastHit = { attackerId: att.id, weaponId: 'ar', isHead: !!head, dist: 8 };
  };
  const cases = [
    ['front body', 0, false, false, false, 'death_front'], ['back body', Math.PI, false, false, false, 'death_back'], ['right body', Math.PI / 2, false, false, false, 'death_right'],
    ['front head', 0, true, false, false, 'death_front_head'], ['back head', Math.PI, true, false, false, 'death_back_head'],
    ['crouch head (front)', 0, true, true, false, 'death_crouch_head'], ['crouch head (back)', Math.PI, true, true, false, 'death_crouch_head'],
  ];
  for (const [name, ang, head, crouch, moving, want] of cases) {
    W.simTick = 1000; place(ang, head, crouch, moving);
    out.cases.push({ name, want, got: P.pickDeath(vic) });
  }
  // left hit: no clip of its own, takes front or back; head -> a head variant
  W.simTick = 1000; place(-Math.PI / 2, false, false, false); const left = P.pickDeath(vic);
  out.cases.push({ name: 'left body', want: 'death_front|death_back', got: left, ok: left === 'death_front' || left === 'death_back' });
  W.simTick = 1000; place(-Math.PI / 2, true, false, false); const lefth = P.pickDeath(vic);
  out.cases.push({ name: 'left head', want: 'death_front_head|death_back_head', got: lefth, ok: lefth === 'death_front_head' || lefth === 'death_back_head' });
  // no attacker at all (storm): any non-crouch fall
  vic.lastHit = null; vic.crouching = false; vic.vel.set(0, 0, 0); W.simTick = 1000; const storm = P.pickDeath(vic);
  out.cases.push({ name: 'no attacker', want: 'any fall but death_crouch_head/walking', got: storm, ok: !!storm && storm !== 'death_crouch_head' });
  // determinism + seeded variation
  place(-Math.PI / 2, false, false, false);
  W.simTick = 4242; const a1 = P.pickDeath(vic), a2 = P.pickDeath(vic);
  out.det = { a1, a2, same: a1 === a2 };
  const seenLeft = new Set(); for (let t = 0; t < 60; t++) { W.simTick = t * 7 + 1; seenLeft.add(P.pickDeath(vic)); }
  out.vary = { distinct: [...seenLeft] };
  // movers: death_walking sometimes, a directional fall otherwise
  place(0, false, false, true);
  const seenMove = {}; for (let t = 0; t < 80; t++) { W.simTick = t * 13 + 5; const k = P.pickDeath(vic); seenMove[k] = (seenMove[k] || 0) + 1; }
  out.walk = seenMove;
  // restore
  vic.pos.copy(save.pos); vic.vel.copy(save.vel); vic.lastHit = save.lh; vic.crouching = save.crouch; vic.obj.rotation.y = save.rot; att.pos.copy(save.apos); W.simTick = save.tick;
  return out;
}"""

FACING_JS = r"""() => {
  const Cn = window.__LC__, W = Cn.W;
  Cn.stepFrames(4, 1 / 60, false);
  const bots = W.actors.filter((a) => a.alive && !a.isDummy && a.rig && a.onGround).slice(0, 8);
  const out = []; const v1 = new W.camera.position.constructor(), v2 = new W.camera.position.constructor();
  const bone = (a, re) => { let r = null; a.rig.scene.traverse((o) => { if (!r && o.isBone && re.test(o.name)) r = o; }); return r; };
  for (const a of bots) {
    a.obj.updateMatrixWorld(true);
    const b = a.obj.rotation.y, fx = Math.sin(b), fz = Math.cos(b), rx = -Math.cos(b), rz = Math.sin(b);
    const hips = bone(a, /Hips$/), rh = bone(a, /RightHand$/), toe = bone(a, /RightToeBase$/), foot = bone(a, /RightFoot$/);
    if (!hips || !rh || !toe || !foot) continue;
    hips.getWorldPosition(v1); rh.getWorldPosition(v2);
    const rightDot = (v2.x - v1.x) * rx + (v2.z - v1.z) * rz;
    toe.getWorldPosition(v1); foot.getWorldPosition(v2);
    const toeDot = (v1.x - v2.x) * fx + (v1.z - v2.z) * fz;
    out.push({ id: a.id, skin: a.skin, toeForward: +toeDot.toFixed(3), handRight: +rightDot.toFixed(3) });
    if (out.length >= 6) break;
  }
  return out;
}"""

KILL_JS = r"""([which]) => {
  const Cn = window.__LC__, W = Cn.W, P = W._playerProbe;
  const cands = W.actors.filter((a) => a.alive && !a.isDummy && a !== W.player && a.rig && a.onGround);
  const v = cands[which % cands.length];
  v.hp = 1; v.shield = 0;
  W.hurtActor(v, 999, W.player.id, 'ar', false);
  window.__PL_V__ = v;
  return Object.assign({ id: v.id, alive: v.alive, y: v.obj.position.y }, P.corpse(v));
}"""

STATE_JS = r"""() => {
  const W = window.__LC__.W, v = window.__PL_V__, P = W._playerProbe;
  return Object.assign({ y: +v.obj.position.y.toFixed(4), freed: !!v.rig.__lcFreed, mixerListed: W.kernel._mixers.indexOf(v.rig.mixer) >= 0, paused: !!W.paused, hitstopT: +(W.hitstopT || 0).toFixed(3) }, P.corpse(v));
}"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    C.add_common_args(ap)
    PL.add_args(ap)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--map", default="isla_viva", choices=C.MAPS)
    ap.add_argument("--kills", type=int, default=20)
    ap.add_argument("--max-frames", type=int, default=16000)
    args = ap.parse_args()
    PL.prepare(args)

    def body(v):
        with C.Session(args, "player_deaths") as s:
            PL.overlay(s, args)
            PL.served_note(v, args)
            s.boot()
            s.start_match("standard", args.seed, args.map)
            s.guard_player(True)
            v.info("land", s.land(120, protect=True))
            s.freeze_loop()
            s.step_frames(10, 1 / 60, render=False)
            probe = s.js("() => { const p = window.__LC__.W._playerProbe; return p ? { clips: p.clips(), canopy: p.canopy(), deathClips: p.deathClips } : null; }")
            v.info("probe", probe)
            if not probe:
                v.cnj("probe hook", "W._playerProbe is missing")
                return
            # --- (1) natural kills
            nat = s.js(NATURAL_JS, [args.kills, args.max_frames])
            rows = nat["rows"]
            v.info("natural kills", {"n": len(rows), "frames": nat["frames"], "clips": [r["anim"] for r in rows]})
            v.data["natural"] = rows
            if len(rows) < args.kills:
                v.cnj("20 natural bot kills", "only %d bot deaths in %d stepped frames (t=%s)" % (len(rows), nat["frames"], nat["w_t"]))
            used = sorted({r["anim"] for r in rows})
            v.check("natural kills: >= 5 distinct falls among %d" % len(rows), len(used) >= 5 and len(rows) >= 10, {"distinct": len(used), "used": used,
                    "counts": {k: sum(1 for r in rows if r["anim"] == k) for k in used}})
            bad = [r["anim"] for r in rows if r["anim"] not in DEATHS]
            v.check("natural kills: every fall is one of the seven Mixamo clips (no death2 / death3 / plain death)", not bad, {"offenders": bad[:6]})
            measured = [r for r in rows if r["hipsEnd"] is not None]
            tall = [r for r in measured if r["hipsEnd"] > 0.6]
            if not measured:
                v.cnj("no corpse with hips > 0.6 m at clip end", "no corpse was measured at clip end")
            else:
                v.check("no corpse with hips > 0.6 m at clip end (%d measured)" % len(measured), not tall,
                        {"measured": len(measured), "max": max(r["hipsEnd"] for r in measured), "tall": tall[:4]})
            # --- (2) pickDeath as a pure function
            fo = s.js(FORCED_JS)
            v.info("forced pickDeath", fo)
            if fo.get("error"):
                v.cnj("pickDeath mapping", fo["error"])
            else:
                cs = fo["cases"]
                v.check("pickDeath maps front/back/right/head/crouch hits to the right fall", all((c.get("ok") if "ok" in c else c["got"] == c["want"]) for c in cs),
                        [(c["name"], c["want"], c["got"]) for c in cs if not (c.get("ok") if "ok" in c else c["got"] == c["want"])] or "all %d cases" % len(cs))
                v.check("pickDeath is deterministic (same seed, victim, tick -> same fall)", fo["det"]["same"], fo["det"])
                v.check("pickDeath varies a side hit across ticks (seeded, not constant)", len(fo["vary"]["distinct"]) >= 2, fo["vary"])
                v.check("a mover gets death_walking sometimes and a directional fall otherwise", fo["walk"].get("death_walking", 0) > 0 and any(k != "death_walking" for k in fo["walk"]), fo["walk"])
                v.check("every one of the seven clips is bound on the rig (clips map)", all(d in fo["avail"] for d in DEATHS), fo["avail"])
            # --- (3) facing maths vs the real skeleton
            fc = s.js(FACING_JS)
            v.info("facing (toe . forward, right hand . right)", fc)
            if len(fc) < 3:
                v.cnj("the facing maths matches the real skeleton", "fewer than 3 grounded bots measured")
            else:
                v.check("the facing maths matches the real skeleton (toes along (sin b, cos b), right hand on the (-cos b, sin b) side)",
                        all(x["toeForward"] > 0.02 and x["handRight"] > 0.0 for x in fc), fc)
            # --- (4) corpse timeline on sim time
            k0 = s.js(KILL_JS, [3])
            v.info("kill A", k0)
            if k0["alive"]:
                v.cnj("corpse timeline", "the test victim did not die")
            else:
                s.step_frames(30, 1 / 60, render=False)
                a0 = s.js(STATE_JS)
                s.sleep(3.6)                                   # a real wait; NO frames are stepped, the sim does not move
                a1 = s.js(STATE_JS)
                s.step_frames(30, 1 / 60, render=False)
                a2 = s.js(STATE_JS)
                v.info("wall-clock test", {"after 0.5 s sim": a0, "after 3.6 s real wait": a1, "after 1.0 s sim": a2})
                v.check("a real 3.6 s wait with no frames stepped does not advance the corpse (sim time, not setTimeout)",
                        abs(a1["sinkT"] - a0["sinkT"]) < 1e-9 and abs(a1["y"] - a0["y"]) < 1e-9 and a1["parented"], {"before": a0, "after": a1})
                v.check("the corpse holds its pose for the sim hold (_sinkT advanced by the stepped 0.5 s only, still parented, lifted off the floor)",
                        abs((a2["sinkT"] - a1["sinkT"]) - 0.5) < 0.05 and a2["parented"] and a2["y"] > a2["y0"] + 0.02, {"a1": a1, "a2": a2})
                # step into the sink, then pause
                need = a2["hold"] + 0.45 - a2["sinkT"]
                s.step_frames(int(round(need * 60)), 1 / 60, render=False)
                s1 = s.js(STATE_JS)
                s.js("() => { window.__LC__.W.paused = true; }")
                s.step_frames(300, 1 / 60, render=False)
                s2 = s.js(STATE_JS)
                s.js("() => { window.__LC__.W.paused = false; }")
                v.info("pause test", {"sinking": s1, "after 300 paused frames": s2})
                v.check("the sink is IN PROGRESS when paused (y below the hold height)", s1["parented"] and s1["y"] < s1["y0"] + 0.1 - 0.01, s1)
                v.check("a pause freezes the sink exactly (y and _sinkT unchanged over 300 stepped frames, body still there)",
                        s2["y"] == s1["y"] and s2["sinkT"] == s1["sinkT"] and s2["parented"] and s2["paused"], {"before": s1, "after": s2})
                s.step_frames(150, 1 / 60, render=False)
                s3 = s.js(STATE_JS)
                v.check("on resume the sink finishes (body removed, rig freed, mixer off the kernel list)", (not s3["parented"]) and s3["freed"] and not s3["mixerListed"], s3)
                # hit-stop
                k1 = s.js(KILL_JS, [5])
                s.step_frames(20, 1 / 60, render=False)
                h0 = s.js(STATE_JS)
                s.js("() => { window.__LC__.W.hitstopT = 0.9; }")
                s.step_frames(40, 1 / 60, render=False)
                h1 = s.js(STATE_JS)
                d = h1["sinkT"] - h0["sinkT"]
                v.info("hit-stop test", {"before": h0, "after": h1, "sinkT advanced": round(d, 4)})
                v.check("hit-stop slows the corpse (a 0.667 s hit-stop window advances _sinkT by 0.05-0.14 s, not 0.667)", 0.05 <= d <= 0.14, {"advanced": round(d, 4)})
            s.guard_player(False)
            dg = s.diagnostics()
            v.data["diagnostics"] = dg
            C.print_diagnostics(dg)
            v.check("0 console errors", not dg["consoleErrors"], dg["consoleErrors"][:5])
            v.check("0 page / window errors", not (dg["pageErrors"] or dg["windowErrors"]), (dg["pageErrors"] + dg["windowErrors"])[:5])
            v.check("0 failed requests", not dg["failedRequests"], dg["failedRequests"][:8])
            v.check("0 shader errors, 0 [rig] lines", not dg["shader"] and not dg["rigWarnings"], (dg["shader"] + dg["rigWarnings"])[:4])
    return C.run_gate("player_deaths", body, args)


if __name__ == "__main__":
    sys.exit(main())
