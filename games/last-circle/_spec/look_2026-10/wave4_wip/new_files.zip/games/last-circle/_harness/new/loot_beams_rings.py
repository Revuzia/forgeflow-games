#!/usr/bin/env python
"""loot_beams_rings - LOOT lane (Wave 4) gate for look plan P1.3: rarity light beams + glowing floor rings as instanced draws.

    python _harness/new/loot_beams_rings.py --disk [--only pools,clamp,ceilpix,pickup,rings,glare] [--shots DIR]

One standard match on isla_viva seed 7 (the research's measured seed: 124 weapons / 157 ammo / 65 consumables / 51 chests). Rows:

  pools      the markers are THREE instanced meshes (loot-rings / loot-beams / loot-glows) at renderOrder >= 6; the loot group holds no
             per-item ring torus and no sprite; the three add exactly 3 draw calls (renderer.info delta, markers shown vs hidden);
             census: every floor weapon has a ring and a beam, ammo / consumables a ring and NO beam, every chest ring + beam + glow;
             beam heights follow the rarity table (common ~2 m ... legendary ~14 m) when nothing is above them
  clamp      EVERY beam's drawn top <= the underside of the first collider above it - 4 cm, checked against an independent brute-force
             pass over ALL map colliders (not the spatial grid the module used); the under-roof census is printed (research: 69 of 346
             floor items and 17 of 51 chests on this seed before bots take any)
  ceilpix    no beam PIXEL above a ceiling collider: for under-roof beams the scene is rendered (float RT, no bloom) with beams shown
             and hidden from outside the building; the column above the projected ceiling must be identical. CONTROL: the same view
             with the clamp deliberately removed (the beam's drawn height forced to nominal) MUST show beam pixels there - a probe
             that cannot fail is reported as could-not-judge
  pickup     picking an item (E / walkover path), a net take mirror, and opening a chest each park their ring / beam / glow slot (zero
             matrix, free list) and the region renders identically with the markers hidden afterwards (and does NOT before)
  deaths     a killed bot's drops: every dropped item has a ring and a glow, every dropped weapon also a beam (and takes them away on pickup)
  chestview  from 250 m up (the glider) the chest beams are still drawn: >= 70 % of the chests within 900 m in view show beam pixels
  rings      A/B (ring shown / hidden, same frame state, scene + beams + glows otherwise identical): on SAND, GRASS and WOOD (a wooden
             structure top) each rarity ring's band pixels read as the rarity colour (hue error < 15 deg on the displayed pixel) at
             >= 1.4x the floor luminance (scene-linear HDR, pre-bloom, pre-tonemap)
  glare      INFORMATION: beam axis radiance vs the pixel behind it, and the bloom-weighted luminance of the beam's own contribution
             (common / uncommon must stay under the 0.72 bloom threshold), per rarity
  errors     0 page errors, 0 console errors, 0 failed requests, 0 shader errors from the loot materials (a shader error from another
             lane's material is printed as information with its material name)

Exit 0 pass / 1 fail / 2 could-not-judge. Milliseconds are never judged.
"""
from __future__ import annotations

import argparse
import base64
import io
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import common as C  # noqa: E402

try:
    import numpy as np
    from PIL import Image
except Exception:  # pragma: no cover
    np = None
    Image = None

RARITY_HEX = {0: "#9da5b4", 1: "#3ec46d", 2: "#3fa9f5", 3: "#b05cf0", 4: "#f2a33c"}
RARITY_NAME = ["common", "uncommon", "rare", "epic", "legendary"]
BEAM_NOMINAL = {0: 2.0, 1: 4.0, 2: 7.0, 3: 10.5, 4: 14.0}

LG_JS = r"""() => {
  if (window.__LG__) return 'already';
  const W = window.__LC__.W, k = W.kernel, r = k.renderer, THREE = W.THREE;
  const LG = window.__LG__ = {};
  const cvs = r.domElement;
  const b64 = (buf) => { let s = ''; const u8 = new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength); const CH = 0x8000;
    for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH)); return btoa(s); };
  LG.canvas = () => [cvs.width, cvs.height];
  LG.tp = (x, z, y) => { const p = W.player; p.pos.x = x; p.pos.z = z; p.pos.y = (y == null ? W.map.heightAt(x, z) : y) + 0.05;
    if (p.vel) { p.vel.x = 0; p.vel.y = 0; p.vel.z = 0; } return [p.pos.x, p.pos.y, p.pos.z]; };
  LG.face = (tx, tz, pitch, yawOff) => { const p = W.player; const dx = tx - p.pos.x, dz = tz - p.pos.z;
    const y = Math.atan2(-dx, -dz) + (yawOff || 0); p.input.yaw = y; p.yaw = y; p.input.pitch = pitch; return y; };
  LG.project = (x, y, z) => { const v = new THREE.Vector3(x, y, z).project(W.camera);
    return [(v.x * 0.5 + 0.5) * cvs.width, (1 - (v.y * 0.5 + 0.5)) * cvs.height, v.z]; };
  LG.vis = (rings, beams, glows) => { const m = W.debugLootFx().meshes; m[0].visible = !!rings; m[1].visible = !!beams; m[2].visible = !!glows; };
  LG.spawn = (id, data, x, z, y) => { W.netSpawnItem({ id, data, x, y: y == null ? W.map.heightAt(x, z) + 0.15 : y, z }); return W.debugLootFx(id).obj; };
  LG.info = (id) => { const d = W.debugLootFx(id); return d && d.obj ? d.obj : null; };
  // one measured frame: hdr = the scene (no composer, no bloom, no tone map) into a private FLOAT target; srgb = the composed frame
  // exactly as displayed. rect = [x, y, w, h] in canvas px, top-left origin.
  LG.frame = (rect, wantHdr, wantSrgb) => {
    const out = {}; const w = cvs.width, h = cvs.height; const [x, y, rw, rh] = rect;
    if (wantHdr) {
      if (!LG.rt || LG.rt.width !== w || LG.rt.height !== h) { if (LG.rt) LG.rt.dispose();
        LG.rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.FloatType, format: THREE.RGBAFormat, depthBuffer: true }); }
      const prev = r.getRenderTarget();
      r.setRenderTarget(LG.rt); r.clear(); r.render(k.scene, k.camera);
      const buf = new Float32Array(rw * rh * 4); r.readRenderTargetPixels(LG.rt, x, h - y - rh, rw, rh, buf);
      r.setRenderTarget(prev); out.hdr = b64(buf);
    }
    if (wantSrgb) {
      if (k.composer) k.composer.render(0); else { r.setRenderTarget(null); r.render(k.scene, k.camera); }
      const gl = r.getContext(); r.setRenderTarget(null);
      const buf = new Uint8Array(rw * rh * 4); gl.readPixels(x, h - y - rh, rw, rh, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      out.srgb = b64(buf);
    }
    return out;
  };
  // free spot search: terrain height in [lo, hi] over a (2*span)^2 patch, max relief, no collider within span + 3 m
  LG.findSpot = (lo, hi, span, maxRel, from, minFrom) => {
    const M = W.map, half = M.half * 0.78; let best = null;
    for (let x = -half; x <= half; x += 9) for (let z = -half; z <= half; z += 9) {
      const h0 = M.heightAt(x, z); if (h0 < lo || h0 > hi) continue;
      let ok = true, mn = 1e9, mx = -1e9;
      for (let dx = -span; dx <= span && ok; dx += span / 2) for (let dz = -span; dz <= span; dz += span / 2) {
        const q = M.heightAt(x + dx, z + dz); if (q < lo - 0.25 || q > hi + 0.25) { ok = false; break; } mn = Math.min(mn, q); mx = Math.max(mx, q); }
      if (!ok || mx - mn > maxRel) continue;
      if (M.queryColliders(x, z, span + 3, []).length) continue;
      if (from && Math.hypot(x - from[0], z - from[1]) < (minFrom || 0)) continue;
      const rel = mx - mn; if (!best || rel < best.rel) best = { x, z, h: h0, rel };
    }
    return best;
  };
  // WOOD: no map in this build has a wooden floor (house floors are the terrain), so the wood case drapes a wood-brown, lit, shadow-receiving
  // plane over the terrain 3 cm up (below the ring's 6.5 cm), exactly like a plank deck would sit. Gate-only object, removed afterwards.
  LG.planks = [];
  LG.plank = (cx, cz, half, hex) => { const M = W.map; const geo = new THREE.PlaneGeometry(half * 2, half * 2, 24, 24); geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) { const x = cx + pos.getX(i), z = cz + pos.getZ(i); pos.setXYZ(i, x, M.heightAt(x, z) + 0.03, z); }
    geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: hex, roughness: 0.85, metalness: 0 }));
    m.receiveShadow = true; m.name = '__lg_plank'; W.scene.add(m); LG.planks.push(m); return LG.planks.length; };
  LG.unplank = () => { for (const m of LG.planks) { W.scene.remove(m); m.geometry.dispose(); m.material.dispose(); } LG.planks = []; return 'ok'; };
  // independent re-cast for the clamp row: brute force over ALL colliders (the module uses the spatial grid)
  LG.ceilBrute = (x, z, floor, rad) => { let c = Infinity, by = null;
    for (const o of W.map.colliders) { if (o.dead) continue;
      if (o.maxX < x - rad || o.minX > x + rad || o.maxZ < z - rad || o.minZ > z + rad) continue;
      if (o.minY > floor + 0.6 && o.minY < c) { c = o.minY; by = [o.minX, o.maxX, o.minZ, o.maxZ, o.maxY]; } }
    return { ceil: c === Infinity ? null : c, by }; };
  return 'ok';
}"""

CENSUS_JS = r"""() => {
  const W = window.__LC__.W, g = W.group('loot'), d = W.debugLootFx();
  let torus = 0, sprites = 0; const inst = [];
  g.traverse((o) => { if (o.isSprite) sprites++; if (o.isMesh && o.geometry && o.geometry.type === 'TorusGeometry') torus++;
    if (o.isInstancedMesh && /^loot-(rings|beams|glows)$/.test(o.name)) inst.push({ name: o.name, ro: o.renderOrder, count: o.count, inGroup: o.parent === g }); });
  const rows = [];
  for (const it of W.debugItems()) { const o = W.debugLootFx(it.id).obj; if (!o) continue;
    rows.push({ id: it.id, kind: it.data.kind, did: it.data.id, r: it.data.rarity || 0, ring: o.ring ? o.ring.slot : -1, beam: o.beam ? o.beam.slot : -1,
                glow: o.glow ? o.glow.slot : -1, ringAlive: !!(o.ring && o.ring.alive), top: o.beam ? o.beam.top : null, by: o.beam ? o.beam.y : null,
                nominal: o.beam ? o.beam.nominal : null, size: o.beam ? o.beam.size : null, x: it.pos.x, y: it.pos.y, z: it.pos.z, ceil: o.ceil === Infinity ? null : o.ceil,
                th: W.map.heightAt(it.pos.x, it.pos.z) }); }
  const chests = W.debugChests().map((c) => { const o = W.debugLootFx(c.id).obj; return { id: c.id, opened: c.opened, ring: c.ring, beam: c.beam, glow: c.glow,
      top: o && o.beam ? o.beam.top : null, by: o && o.beam ? o.beam.y : null, nominal: o && o.beam ? o.beam.nominal : null, x: c.pos.x, y: c.pos.y, z: c.pos.z, ceil: c.ceil === Infinity ? null : c.ceil }; });
  return { torus, sprites, inst, rows, chests, fx: { beams: d.beams, rings: d.rings, glows: d.glows } };
}"""

CALLS_JS = r"""() => {
  const W = window.__LC__.W, k = W.kernel, r = k.renderer, m = W.debugLootFx().meshes;
  const was = r.info.autoReset; r.info.autoReset = false;
  const run = () => { r.info.reset(); if (k.composer) k.composer.render(0); else r.render(k.scene, k.camera); return r.info.render.calls; };
  const vis = m.map((o) => o.visible);
  m.forEach((o) => { o.visible = true; }); const on = run();
  m.forEach((o) => { o.visible = false; }); const off = run();
  m.forEach((o, i) => { o.visible = vis[i]; }); r.info.autoReset = was;
  return { on, off, delta: on - off, counts: m.map((o) => o.count) };
}"""


# ───────────────────────────── helpers ─────────────────────────────
def dec_f32(b, w, h):
    a = np.frombuffer(base64.b64decode(b), dtype=np.float32).reshape(h, w, 4)
    return a[::-1].astype(np.float64)               # rows bottom-up -> top-down


def dec_u8(b, w, h):
    a = np.frombuffer(base64.b64decode(b), dtype=np.uint8).reshape(h, w, 4)
    return a[::-1].astype(np.float64)


def lum(a):
    return 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]


def srgb_to_lin(c):
    c = np.asarray(c, dtype=np.float64)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def hex_rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])


def hue_deg(rgb):
    """Vectorised HSV hue in degrees for an (..., 3) array in 0..1."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = np.max(rgb, axis=-1); mn = np.min(rgb, axis=-1); d = mx - mn
    h = np.zeros_like(mx)
    m = d > 1e-9
    rc = np.where(m & (mx == r), ((g - b) / np.where(m, d, 1)) % 6, 0)
    gc = np.where(m & (mx == g) & (mx != r), (b - r) / np.where(m, d, 1) + 2, 0)
    bc = np.where(m & (mx == b) & (mx != r) & (mx != g), (r - g) / np.where(m, d, 1) + 4, 0)
    h = np.where(mx == r, rc, np.where(mx == g, gc, bc)) * 60.0
    return np.where(m, h % 360.0, 0.0)


def hue_err(a, b):
    d = np.abs(a - b) % 360.0
    return np.minimum(d, 360.0 - d)


def sat(rgb):
    mx = np.max(rgb, axis=-1); mn = np.min(rgb, axis=-1)
    return np.where(mx > 1e-9, (mx - mn) / np.where(mx > 1e-9, mx, 1), 0.0)


def save_png(arr, path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).save(path)


class Rig:
    """Thin wrapper over a Session with the in-page helper installed."""

    def __init__(self, s):
        self.s = s
        s.js(LG_JS)
        self.size = s.js("() => window.__LG__.canvas()")

    def js(self, expr, arg=None):
        return self.s.js(expr, arg)

    def settle(self, n=8):
        self.s.step_frames(n, 1 / 60, True)

    def place(self, ix, iz, dist=4.0, pitch=-0.40, yaw_off=0.38, y=None, from_dir=(0.0, 1.0)):
        """Player `dist` m from (ix, iz) along from_dir, facing the item, aim turned yaw_off so the item sits off-centre."""
        px, pz = ix + from_dir[0] * dist, iz + from_dir[1] * dist
        self.js("([x, z, y, ix, iz, pt, yo]) => { window.__LG__.tp(x, z, y); window.__LG__.face(ix, iz, pt, yo); }",
                [px, pz, y, ix, iz, pitch, yaw_off])
        self.settle(8)

    def rect_around(self, x, y, z, rad, pad=14):
        """Canvas rect bounding a horizontal disc of radius rad at (x, y, z)."""
        pts = []
        for i in range(16):
            a = i / 16 * math.tau
            pts.append(self.js("([x, y, z]) => window.__LG__.project(x, y, z)", [x + math.cos(a) * rad, y, z + math.sin(a) * rad]))
        W, H = self.size
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        x0 = max(0, int(min(xs)) - pad); x1 = min(W, int(max(xs)) + pad)
        y0 = max(0, int(min(ys)) - pad); y1 = min(H, int(max(ys)) + pad)
        return [x0, y0, max(8, x1 - x0), max(8, y1 - y0)]

    def grab(self, rect, hdr=True, srgb=True):
        o = self.js("([r, a, b]) => window.__LG__.frame(r, a, b)", [rect, hdr, srgb])
        w, h = rect[2], rect[3]
        res = {}
        if hdr:
            res["hdr"] = dec_f32(o["hdr"], w, h)
        if srgb:
            res["srgb"] = dec_u8(o["srgb"], w, h)
        return res

    def ab(self, rect, off, hdr=True, srgb=True):
        """Shown vs hidden: off = (rings, beams, glows) visibility for the OFF frame; the ON frame shows everything."""
        self.js("() => window.__LG__.vis(true, true, true)")
        on = self.grab(rect, hdr, srgb)
        self.js("([a, b, c]) => window.__LG__.vis(a, b, c)", list(off))
        of = self.grab(rect, hdr, srgb)
        self.js("() => window.__LG__.vis(true, true, true)")
        return on, of


# ───────────────────────────── the gate ─────────────────────────────
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    C.add_common_args(ap)
    ap.add_argument("--map", default="isla_viva")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--only", default="", help="comma list of rows to run: pools,clamp,ceilpix,pickup,deaths,chestview,rings,glare")
    ap.add_argument("--shots", default=None, help="directory for the A/B contact PNGs (default _harness/_shots/loot)")
    ap.add_argument("--hue-tol", type=float, default=15.0)
    ap.add_argument("--min-lum-ratio", type=float, default=1.4)
    args = ap.parse_args()
    only = {x.strip() for x in args.only.split(",") if x.strip()}
    want = lambda n: not only or n in only  # noqa: E731
    shots = args.shots or os.path.join(C.SHOTS, "loot")

    def body(v):
        if np is None:
            v.cnj("numpy / PIL", "numpy and Pillow are required for the pixel rows")
            return
        with C.Session(args, "loot_beams_rings") as s:
            s.boot()
            sm = s.start_match("standard", args.seed, args.map, enter=True)
            v.info("startMatch", sm)
            s.guard_player(True)
            v.info("land", s.land(protect=True))
            rig = Rig(s)
            v.info("canvas", rig.size)
            cen = s.js(CENSUS_JS)
            rows, chests = cen["rows"], cen["chests"]
            v.info("loot census (live after landing)", {"items": len(rows), "weapons": sum(1 for r in rows if r["kind"] == "weapon"),
                                                          "ammo": sum(1 for r in rows if r["kind"] == "ammo"),
                                                          "consumables": sum(1 for r in rows if r["kind"] == "consumable"), "chests": len(chests), "fx": cen["fx"]})

            # ---- pools -------------------------------------------------------------------------------------------------
            if want("pools"):
                names = {m["name"]: m for m in cen["inst"]}
                ok_names = all(n in names for n in ("loot-rings", "loot-beams", "loot-glows"))
                v.check("pools: markers are 3 instanced meshes (loot-rings / loot-beams / loot-glows) in the loot group, renderOrder >= 6",
                        ok_names and all(m["ro"] >= 6 and m["inGroup"] for m in names.values()), cen["inst"], expect="3 meshes, renderOrder >= 6")
                v.check("pools: no per-item ring torus and no sprite left in the loot group", cen["torus"] == 0 and cen["sprites"] == 0,
                        {"torus": cen["torus"], "sprites": cen["sprites"]}, expect="0 / 0 (was 1 torus per floor item + 55 chest sprites)")
                calls = s.js(CALLS_JS)
                v.check("pools: the markers add exactly 3 draw calls", calls["delta"] == 3, calls, expect="3 (was ~8 beams + ~8 glows + ~12 rings in the ground frustum)")
                wp = [r for r in rows if r["kind"] == "weapon"]
                other = [r for r in rows if r["kind"] != "weapon"]
                # an item the module could not put a ring under (nothing within 0.9 m below it) has no markers by design
                noring_w = [r for r in wp if r["ring"] < 0]
                v.check("pools: every floor weapon has a ring and a beam (a beam only where >= 0.35 m of headroom)",
                        len(noring_w) <= max(1, int(0.02 * len(wp))) and all(r["beam"] >= 0 for r in wp if r["ring"] >= 0 and (r["ceil"] is None or r["ceil"] - r["by"] > 0.5 if r["by"] is not None else True)),
                        {"weapons": len(wp), "noRing": len(noring_w), "noBeam": sum(1 for r in wp if r["beam"] < 0), "sample": noring_w[:3]})
                v.check("pools: ammo and consumables get a ring and NO beam",
                        all(r["beam"] < 0 for r in other) and sum(1 for r in other if r["ring"] < 0) <= max(1, int(0.02 * len(other))),
                        {"n": len(other), "withBeam": sum(1 for r in other if r["beam"] >= 0), "noRing": sum(1 for r in other if r["ring"] < 0)})
                live_ch = [c for c in chests if not c["opened"]]
                v.check("pools: every unopened chest has a ring, a beam and a glow", all(c["ring"] >= 0 and c["glow"] >= 0 and c["beam"] >= 0 for c in live_ch),
                        {"chests": len(live_ch), "missing": [c["id"] for c in live_ch if min(c["ring"], c["glow"], c["beam"]) < 0][:5]})
                # beam heights follow the rarity table where nothing is above
                bad = []
                for r in wp:
                    if r["beam"] >= 0 and r["ceil"] is None and abs(r["nominal"] - BEAM_NOMINAL[r["r"]]) > 1e-3:
                        bad.append((r["id"], r["r"], r["nominal"]))
                    if r["beam"] >= 0 and r["ceil"] is None and abs((r["top"] - r["by"]) - BEAM_NOMINAL[r["r"]]) > 1e-3:
                        bad.append((r["id"], r["r"], "drawn", r["top"] - r["by"]))
                v.check("pools: beam height by rarity (common 2 m ... legendary 14 m) where nothing is above", not bad, {"bad": bad[:5], "checked": sum(1 for r in wp if r["beam"] >= 0 and r["ceil"] is None)})

            # ---- clamp (independent brute-force re-cast) -------------------------------------------------------------
            under = []
            if want("clamp") or want("ceilpix"):
                allb = [dict(r, what="item") for r in rows if r["beam"] >= 0] + [dict(c, what="chest") for c in chests if not c["opened"] and c["beam"] >= 0]
                bad, checked, n_under, mism = [], 0, 0, []
                for b in allb:
                    # the beam's own base radius is in its matrix size; the module's footprint rule is radius + 0.12
                    info = s.js("(id) => { const o = window.__LC__.W.debugLootFx(id).obj; return o && o.beam ? { size: o.beam.size, y: o.beam.y, top: o.beam.top } : null; }", b["id"])
                    if not info:
                        continue
                    rad = info["size"] + 0.12
                    floor = info["y"] - 0.04
                    brute = s.js("([x, z, f, r]) => window.__LG__.ceilBrute(x, z, f, r)", [b["x"], b["z"], floor, rad])
                    checked += 1
                    cb = brute["ceil"]
                    if cb is not None:
                        n_under += 1
                        under.append(dict(b, ceilBrute=cb, by_=brute["by"], size=info["size"], floor=floor))
                        if info["top"] > cb - 0.039:
                            bad.append((b["id"], round(info["top"], 3), round(cb, 3)))
                    if (b["ceil"] is None) != (cb is None) or (cb is not None and abs(b["ceil"] - cb) > 1e-6):
                        mism.append((b["id"], b["ceil"], cb))
                nit = sum(1 for u in under if u["what"] == "item"); nch = sum(1 for u in under if u["what"] == "chest")
                v.info("under-roof census (this seed after landing; research before bots take any: 69 of 346 items, 17 of 51 chests)",
                       {"beams": checked, "underRoofItems": nit, "underRoofChests": nch})
                if want("clamp"):
                    v.check("clamp: every beam's drawn top <= first collider above it - 4 cm (independent brute-force re-cast over all colliders)",
                            checked > 0 and not bad, {"beamsChecked": checked, "underRoof": n_under, "violations": bad[:6]}, expect="0 violations")
                    v.check("clamp: the module's recorded ceiling equals the brute-force ceiling for every beam", not mism, {"mismatches": mism[:6]})

            # ---- ceilpix ---------------------------------------------------------------------------------------------
            if want("ceilpix"):
                clamped = [u for u in under if u["what"] == "item" and u["nominal"] - (u["ceilBrute"] - u["floor"] - 0.08) >= 2.0 and u["ceilBrute"] - u["floor"] > 1.5 and u["ceilBrute"] - u["floor"] < 8]
                clamped.sort(key=lambda u: -(u["nominal"] - (u["ceilBrute"] - u["floor"])))
                picks = []
                for u in clamped:
                    if all(math.hypot(u["x"] - p["x"], u["z"] - p["z"]) > 30 for p in picks):
                        picks.append(u)
                    if len(picks) >= 3:
                        break
                if not picks:
                    v.cnj("ceilpix: no beam pixel above a ceiling collider", "no under-roof beam is clamped by >= 2 m on this seed")
                else:
                    per, ctrl = [], []
                    for u in picks:
                        bx0, bx1, bz0, bz1, bmaxy = u["by_"]
                        cx, cz = (bx0 + bx1) / 2, (bz0 + bz1) / 2
                        # stand outside the roof footprint, on the side away from its centre, far enough that the roof does not fill the view
                        dx, dz = u["x"] - cx, u["z"] - cz
                        n = math.hypot(dx, dz) or 1.0
                        ux, uz = (dx / n, dz / n) if n > 0.5 else (0.0, 1.0)
                        halfd = max(bx1 - bx0, bz1 - bz0) / 2
                        dist = halfd + 26.0            # far enough that a 14 m beam and the roof both fit the 57 deg view
                        mid = (u["ceilBrute"] + u["floor"] + u["nominal"]) / 2.0
                        rig.place(u["x"], u["z"], dist=dist, pitch=0.0, yaw_off=0.0, from_dir=(ux, uz))
                        cam_y = rig.js("() => window.__LC__.W.camera.position.y")
                        pitch = math.atan2(mid - cam_y, dist + 4.0)
                        rig.place(u["x"], u["z"], dist=dist, pitch=pitch, yaw_off=0.0, from_dir=(ux, uz))
                        pc = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [u["x"], u["ceilBrute"] + 0.15, u["z"]])
                        pt = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [u["x"], u["floor"] + u["nominal"], u["z"]])
                        W_, H_ = rig.size
                        if not (0 < pc[0] < W_ and 0 < pt[1] < H_ and pt[1] < pc[1] - 6):
                            per.append({"id": u["id"], "skipped": "ceiling / unclamped top off screen or too close in screen space", "pc": pc, "pt": pt})
                            continue
                        x0 = int(pc[0]) - 10; rect = [max(0, x0), 0, 21, int(pc[1])]
                        on, of = rig.ab(rect, (True, False, True), hdr=True, srgb=False)
                        d = np.abs(on["hdr"][..., :3] - of["hdr"][..., :3]).max(axis=-1)
                        px = int((d > 0.01).sum())
                        # CONTROL: remove the clamp (drawn height := nominal) - the same column must now show the beam above the ceiling
                        rig.js("""([slot, nom]) => { const g = window.__LC__.W.debugLootFx().meshes[1].geometry.getAttribute('aBeam'); window.__LG__._save = g.array[slot * 4];
                                 g.array[slot * 4] = nom; g.needsUpdate = true; g.clearUpdateRanges && g.clearUpdateRanges(); }""", [u["beam"], u["nominal"]])
                        con_on, con_of = rig.ab(rect, (True, False, True), hdr=True, srgb=False)
                        cd = np.abs(con_on["hdr"][..., :3] - con_of["hdr"][..., :3]).max(axis=-1)
                        cpx = int((cd > 0.01).sum())
                        rig.js("""([slot]) => { const g = window.__LC__.W.debugLootFx().meshes[1].geometry.getAttribute('aBeam'); g.array[slot * 4] = window.__LG__._save; g.needsUpdate = true; }""", [u["beam"]])
                        per.append({"id": u["id"], "rarity": RARITY_NAME[u["r"]], "ceil": round(u["ceilBrute"], 2), "nominal": u["nominal"], "pixelsAboveCeiling": px, "controlPixels": cpx,
                                    "rect": rect, "pc": [round(pc[0]), round(pc[1])], "pt": [round(pt[0]), round(pt[1])]})
                        ctrl.append(cpx)
                        os.makedirs(shots, exist_ok=True)
                    judged = [p for p in per if "pixelsAboveCeiling" in p]
                    v.info("ceilpix per sample", per)
                    if not judged:
                        v.cnj("ceilpix: no beam pixel above a ceiling collider", "no sample was framed")
                    elif not any(p["controlPixels"] > 20 for p in judged):
                        v.cnj("ceilpix: no beam pixel above a ceiling collider", "the un-clamped control showed no beam pixels, so this probe cannot fail here: %s" % judged)
                    else:
                        ok = all(p["pixelsAboveCeiling"] == 0 for p in judged if p["controlPixels"] > 20)
                        v.check("ceilpix: no beam pixel above a ceiling collider (clamped beams render nothing above the roof; the un-clamped control does)", ok,
                                {"samples": [{k: p[k] for k in ("id", "rarity", "pixelsAboveCeiling", "controlPixels")} for p in judged]}, expect="0 pixels (control > 20)")

            # ---- pickup / net take / chest open ------------------------------------------------------------------------
            if want("pickup"):
                pl = s.js("() => { const p = window.__LC__.W.player; return [p.pos.x, p.pos.z]; }")
                spot = s.js("([a, b]) => window.__LG__.findSpot(2.5, 25, 6, 0.8, null, 0)", pl)
                if not spot:
                    v.cnj("pickup rows", "no free patch of ground for the pickup probe")
                else:
                    sx, sz = spot["x"], spot["z"]
                    # the landing walkover may have filled the 3-gun cap, and a plain pickup then (correctly) refuses a gun: make room
                    s.js("() => { const p = window.__LC__.W.player; const sl = p.inventory.slots; let kept = 0; for (let i = 0; i < sl.length; i++) { if (sl[i] && sl[i].kind === 'weapon') { if (++kept > 1 && i !== p.inventory.active) sl[i] = null; } } }")
                    s.js("([x, z]) => { const L = window.__LG__; L.spawn('t_pick', { kind: 'weapon', id: 'ar', rarity: 3, mag: 30 }, x, z); L.spawn('t_net', { kind: 'weapon', id: 'smg', rarity: 2, mag: 30 }, x + 6, z); }", [sx, sz])
                    rig.place(sx, sz, dist=3.0, pitch=-0.25, yaw_off=0.3)
                    pre = s.js("() => ({ p: window.__LG__.info('t_pick'), n: window.__LG__.info('t_net'), fx: (() => { const d = window.__LC__.W.debugLootFx(); return [d.beams.live, d.rings.live]; })() })")
                    rect = rig.rect_around(sx, s.js("([x, z]) => window.__LC__.W.map.heightAt(x, z)", [sx, sz]) + 3, sz, 2.5, pad=40)
                    rect[1] = max(0, rect[1] - 160); rect[3] = min(rig.size[1] - rect[1], rect[3] + 200)
                    on0, of0 = rig.ab(rect, (False, False, False), hdr=False, srgb=True)
                    before_px = int((np.abs(on0["srgb"][..., :3] - of0["srgb"][..., :3]).max(axis=-1) > 6).sum())
                    alive_pre = bool(pre["p"] and pre["p"]["ring"] and pre["p"]["ring"]["alive"] and pre["p"]["beam"] and pre["p"]["beam"]["alive"])
                    slots_p = (pre["p"]["ring"]["slot"], pre["p"]["beam"]["slot"]) if alive_pre else None
                    ok_pick = s.js("() => window.__LC__.W.pickupItem(window.__LC__.W.player, 't_pick')")
                    s.js("() => window.__LC__.W.netTakeItem('t_net')")
                    s.step_frames(3, 1 / 60, True)
                    slots_n = (pre["n"]["ring"]["slot"], pre["n"]["beam"]["slot"]) if pre["n"] and pre["n"]["ring"] and pre["n"]["beam"] else None
                    post = s.js("""([sp, sn]) => { const W = window.__LC__.W, m = W.debugLootFx().meshes;
                        const zero = (mesh, slot) => { const a = mesh.instanceMatrix.array; let t = 0; for (let i = 0; i < 16; i++) t += Math.abs(a[slot * 16 + i]); return t === 0; };
                        return { ringZero: zero(m[0], sp[0]), beamZero: zero(m[1], sp[1]), netRingZero: sn ? zero(m[0], sn[0]) : null, netBeamZero: sn ? zero(m[1], sn[1]) : null,
                                 itemGone: !W.debugItems().some((q) => q.id === 't_pick' || q.id === 't_net'),
                                 nearby: W.nearbyLoot(W.player.pos, 12).filter((q) => q.id === 't_pick' || q.id === 't_net').length }; }""", [slots_p, slots_n]) if slots_p else None
                    on1, of1 = rig.ab(rect, (False, False, False), hdr=False, srgb=True)
                    after_px = int((np.abs(on1["srgb"][..., :3] - of1["srgb"][..., :3]).max(axis=-1) > 6).sum())
                    live_post = s.js("() => { const d = window.__LC__.W.debugLootFx(); return [d.beams.live, d.rings.live]; }")
                    v.check("pickup: picking an item and a net-take mirror each park their ring + beam (live slots -2 / -2) and free the slots",
                            bool(ok_pick) and alive_pre and post is not None and post["ringZero"] and post["beamZero"] and post["netRingZero"] and post["netBeamZero"]
                            and post["itemGone"] and post["nearby"] == 0 and live_post[0] == pre["fx"][0] - 2 and live_post[1] == pre["fx"][1] - 2,
                            {"pickupReturned": ok_pick, "aliveBefore": alive_pre, "liveBefore": pre["fx"], "liveAfter": live_post, "post": post})
                    if before_px < 30:
                        v.cnj("pickup: the region renders identically with the markers hidden once the item is gone", "the probe saw only %d marker pixels before the pickup (framing)" % before_px)
                    else:
                        v.check("pickup: the region renders identically with the markers hidden once the item is gone (and did not before)", after_px == 0,
                                {"markerPixelsBefore": before_px, "markerPixelsAfter": after_px}, expect="after == 0, before > 30")
                    # chest open parks its three slots
                    ch = s.js("() => { const W = window.__LC__.W; const c = W.debugChests().find((q) => !q.opened && q.ring >= 0 && q.beam >= 0 && q.glow >= 0); return c ? { id: c.id, ring: c.ring, beam: c.beam, glow: c.glow } : null; }")
                    if not ch:
                        v.cnj("pickup: opening a chest parks its ring + beam + glow", "no unopened chest with all three markers")
                    else:
                        before = s.js("() => { const d = window.__LC__.W.debugLootFx(); return [d.beams.live, d.rings.live, d.glows.live]; }")
                        # the opened chest's slots go back to the free list and the loot it drops may reuse them at once (a gun's beam, an item's
                        # ring), so ownership - not a zero matrix - is what proves the chest let go: the chest record holds no slot, its glow
                        # (drops get none) is gone from the live count, and the chest is no longer a pickup target
                        s.js("(id) => window.__LC__.W.openChest(window.__LC__.W.player, id)", ch["id"])
                        s.step_frames(2, 1 / 60, True)
                        after = s.js("""(id) => { const W = window.__LC__.W, d = W.debugLootFx(), c = W.debugChests().find((q) => q.id === id);
                            return { live: [d.beams.live, d.rings.live, d.glows.live], rec: { opened: c.opened, ring: c.ring, beam: c.beam, glow: c.glow },
                                     targetable: W.nearbyLoot({ x: c.pos.x, y: c.pos.y, z: c.pos.z }, 3).some((q) => q.type === 'chest' && q.id === id) }; }""", ch["id"])
                        v.check("pickup: opening a chest parks its ring + beam + glow slots (the record lets go of all three, the glow count drops by 1)",
                                after["rec"]["opened"] and after["rec"]["ring"] == -1 and after["rec"]["beam"] == -1 and after["rec"]["glow"] == -1
                                and after["live"][2] == before[2] - 1 and not after["targetable"],
                                {"before": before, "after": after, "note": "rings / beams live may rise: the loot the chest drops takes slots of its own"})

            # ---- deaths ------------------------------------------------------------------------------------------------
            if want("deaths"):
                b = s.js("""() => { const W = window.__LC__.W; const a = W.actors.find((x) => x.isBot && x.alive && x.inventory && x.inventory.slots.some((q) => q && q.kind === 'weapon'));
                    if (!a) return null; W.giveItem(a, { kind: 'weapon', id: 'sniper', rarity: 4, mag: 5 }); W.giveItem(a, { kind: 'consumable', id: 'medkit', count: 2 });
                    return { id: a.id }; }""")
                if not b:
                    v.cnj("deaths: a killed bot's drops carry ring + glow (+ beam for a weapon)", "no armed bot alive")
                else:
                    before = s.js("() => { const d = window.__LC__.W.debugLootFx(); return [d.beams.live, d.rings.live, d.glows.live]; }")
                    s.js("(id) => { const W = window.__LC__.W; W.killActor(W.actorById.get(id), W.player, 'ar'); }", b["id"])
                    s.step_frames(2, 1 / 60, True)
                    drops = s.js("""(id) => { const W = window.__LC__.W; return W.debugItems().filter((it) => it.id.indexOf('dd:' + id) === 0).map((it) => { const o = W.debugLootFx(it.id).obj;
                        return { id: it.id, kind: it.data.kind, did: it.data.id, r: it.data.rarity, ring: o.ring ? o.ring.slot : -1, beam: o.beam ? o.beam.slot : -1, glow: o.glow ? o.glow.slot : -1 }; }); }""", b["id"])
                    after = s.js("() => { const d = window.__LC__.W.debugLootFx(); return [d.beams.live, d.rings.live, d.glows.live]; }")
                    okd = bool(drops) and all(d["ring"] >= 0 and d["glow"] >= 0 and ((d["beam"] >= 0) == (d["kind"] == "weapon")) for d in drops)
                    v.check("deaths: a killed bot's drops carry ring + glow, and a beam if (and only if) they are weapons", okd and len(drops) >= 2,
                            {"drops": drops[:8], "nDrops": len(drops), "liveBefore": before, "liveAfter": after})

            # ---- chestview ---------------------------------------------------------------------------------------------
            if want("chestview"):
                pl = s.js("() => { const p = window.__LC__.W.player; return [p.pos.x, p.pos.z]; }")
                s.js("() => { const W = window.__LC__.W, p = W.player; p.pos.x = 330; p.pos.z = 330; p.pos.y = 250; p.onGround = false; if (p.vel) { p.vel.x = p.vel.y = p.vel.z = 0; } }")
                s.js("() => window.__LG__.face(0, 0, -0.30, 0)")
                rig.settle(6)
                W_, H_ = rig.size
                chs = s.js("""() => { const W = window.__LC__.W, c0 = W.camera.position; return W.debugChests().filter((c) => !c.opened && c.beam >= 0).map((c) => { const d = Math.hypot(c.pos.x - c0.x, c.pos.y - c0.y, c.pos.z - c0.z);
                    const o = W.debugLootFx(c.id).obj; return { id: c.id, x: o.beam.x, y: o.beam.y, z: o.beam.z, top: o.beam.top, d }; }); }""")
                full = [0, 0, W_, H_]
                s.js("() => window.__LG__.vis(true, true, true)")
                on = rig.grab(full, True, False)
                s.js("() => window.__LG__.vis(true, false, true)")
                of = rig.grab(full, True, False)
                s.js("() => window.__LG__.vis(true, true, true)")
                dif = np.abs(on["hdr"][..., :3] - of["hdr"][..., :3]).max(axis=-1)
                seen, inview = 0, 0
                detail = []
                for c in chs:
                    if c["d"] > 900:
                        continue
                    p0 = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [c["x"], c["y"] + 0.2, c["z"]])
                    p1 = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [c["x"], c["top"] - 0.2, c["z"]])
                    if not (0 < p0[0] < W_ and 0 < p0[1] < H_ and p0[2] < 1):
                        continue
                    inview += 1
                    x0 = max(0, int(p0[0]) - 6); x1 = min(W_, int(p0[0]) + 7); y0 = max(0, int(min(p0[1], p1[1])) - 6); y1 = min(H_, int(max(p0[1], p1[1])) + 6)
                    n = int((dif[y0:y1, x0:x1] > 0.03).sum())
                    seen += 1 if n >= 3 else 0
                    detail.append((c["id"], round(c["d"]), n))
                if inview < 3:
                    v.cnj("chestview: chest beams are drawn from the glider", "only %d chests within 900 m in view" % inview)
                else:
                    v.check("chestview: from 250 m up >= 70 %% of the chests within 900 m in view still show beam pixels (%d of %d)" % (seen, inview), seen >= 0.7 * inview,
                            {"inView": inview, "seen": seen, "sample": detail[:8]})

            # ---- rings A/B ---------------------------------------------------------------------------------------------
            spots = {}
            if want("rings") or want("glare"):
                pl = s.js("() => { const p = window.__LC__.W.player; return [p.pos.x, p.pos.z]; }")
                spots = {
                    "sand": s.js("([a, b]) => window.__LG__.findSpot(0.8, 1.9, 5, 0.6, [a, b], 0)", pl),
                    "grass": s.js("([a, b]) => window.__LG__.findSpot(4.0, 22.0, 5, 0.6, [a, b], 0)", pl),
                }
                v.info("A/B spots", spots)
                wood = spots.get("grass")      # the wood case drapes a wooden plank over a second visit to the grass patch (see LG.plank)
                v.info("A/B wood", "synthetic wood-brown plank draped over the grass patch: no map has wooden floors in this build")
                RES = []
                os.makedirs(shots, exist_ok=True)
                sheet_tiles = []
                for surf in ("sand", "grass", "wood"):
                    sp = spots.get("grass" if surf == "wood" else surf)
                    if not sp:
                        RES.append({"surface": surf, "skipped": "no spot"})
                        continue
                    top = None
                    if surf == "wood":
                        s.js("([x, z]) => window.__LG__.plank(x, z, 4.5, 0x7a5230)", [sp["x"], sp["z"]])
                    for rar in range(5):
                        iid = "t_%s_%d" % (surf, rar)
                        data = {"kind": "weapon", "id": "ar", "rarity": rar, "mag": 30}
                        y = (top + 0.15) if top is not None else None
                        s.js("([id, d, x, z, y]) => window.__LG__.spawn(id, d, x, z, y)", [iid, data, sp["x"], sp["z"], y])
                        rig.place(sp["x"], sp["z"], dist=4.2, pitch=-0.42, yaw_off=0.40, y=top)
                        info = s.js("(id) => window.__LG__.info(id)", iid)
                        if not info or not info.get("ring") or not info["ring"]["alive"]:
                            RES.append({"surface": surf, "rarity": rar, "skipped": "ring not alive", "info": info})
                            s.js("(id) => window.__LC__.W.netTakeItem(id)", iid)
                            continue
                        ry = info["ring"]["y"]
                        rect = rig.rect_around(sp["x"], ry, sp["z"], 1.15, pad=16)
                        # rings A/B: beams + glows hidden in BOTH frames so only the ring differs
                        rig.js("() => window.__LG__.vis(true, false, false)")
                        on = rig.grab(rect, True, True)
                        rig.js("() => window.__LG__.vis(false, false, false)")
                        of = rig.grab(rect, True, True)
                        rig.js("() => window.__LG__.vis(true, true, true)")
                        C_ = np.array(info["ring"]["color"])               # HDR band colour (linear), the module's own number
                        h_on, h_of = on["hdr"][..., :3], of["hdr"][..., :3]
                        dlt = h_on - h_of
                        cc = C_[None, None, :] - h_of
                        den = (cc * cc).sum(axis=-1)
                        alpha = np.where(den > 1e-6, (dlt * cc).sum(axis=-1) / np.where(den > 1e-6, den, 1), 0.0)
                        band = (alpha >= 0.85) & (np.abs(dlt).max(axis=-1) > 0.05)
                        nb = int(band.sum())
                        rec = {"surface": surf, "rarity": RARITY_NAME[rar], "bandPixels": nb}
                        if nb < 25:
                            rec["skipped"] = "too few band pixels (%d): framing" % nb
                            RES.append(rec)
                        else:
                            y_on = lum(h_on)[band]; y_of = lum(h_of)[band]
                            ratio = y_on / np.maximum(y_of, 1e-4)
                            sr_on = on["srgb"][..., :3][band] / 255.0
                            sr_of = of["srgb"][..., :3][band] / 255.0
                            tgt_h = float(hue_deg(hex_rgb(RARITY_HEX[rar])))
                            tgt_s = float(sat(hex_rgb(RARITY_HEX[rar])))
                            he = hue_err(hue_deg(sr_on), tgt_h)
                            rec.update({"lumRatioHDR_median": round(float(np.median(ratio)), 3), "lumRatioHDR_p10": round(float(np.percentile(ratio, 10)), 3),
                                        "floorLumHDR": round(float(np.median(y_of)), 3), "bandLumHDR": round(float(np.median(y_on)), 3),
                                        "hueErr_median": round(float(np.median(he)), 2), "hueErr_p90": round(float(np.percentile(he, 90)), 2),
                                        "targetHue": round(tgt_h, 1), "targetSat": round(tgt_s, 2),
                                        "displayLumRatio_median": round(float(np.median(lum(srgb_to_lin(sr_on)) / np.maximum(lum(srgb_to_lin(sr_of)), 1e-4))), 3)})
                            RES.append(rec)
                        # contact tiles: ring on | ring off | diff x4
                        a = on["srgb"][..., :3]; b = of["srgb"][..., :3]
                        sheet_tiles.append((surf, rar, np.concatenate([a, b, np.clip(np.abs(a - b) * 4, 0, 255)], axis=1)))
                        s.js("(id) => window.__LC__.W.netTakeItem(id)", iid)
                        s.step_frames(1, 1 / 60, True)
                    if surf == "wood":
                        s.js("() => window.__LG__.unplank()")
                v.data["ringAB"] = RES
                if sheet_tiles:
                    try:
                        wmax = max(t[2].shape[1] for t in sheet_tiles)
                        rowsimg = []
                        for _, _, im in sheet_tiles:
                            pad = np.zeros((im.shape[0], wmax - im.shape[1], 3))
                            rowsimg.append(np.concatenate([im, pad], axis=1))
                        save_png(np.concatenate(rowsimg, axis=0), os.path.join(shots, "ring_ab_sheet.png"))
                        v.info("ring A/B contact sheet (rows: sand c/u/r/e/l, grass ..., wood ...; cols: on | off | diff x4)", os.path.join(shots, "ring_ab_sheet.png"))
                    except Exception as e:  # pragma: no cover
                        v.info("ring A/B sheet not written", str(e)[:200])
                if want("rings"):
                    judged = [r for r in RES if "hueErr_median" in r]
                    for r in RES:
                        v.info("ring A/B %s %s" % (r.get("surface"), r.get("rarity")), {k: r[k] for k in r if k not in ("surface", "rarity")})
                    surfaces_judged = sorted({r["surface"] for r in judged})
                    miss = [r for r in RES if "skipped" in r]
                    if len(surfaces_judged) < 3:
                        v.cnj("rings: rarity-coloured ring on sand, grass and wood", "only judged surfaces %s (skipped: %s)" % (surfaces_judged, [(m.get("surface"), m.get("rarity"), m.get("skipped")) for m in miss][:6]))
                    else:
                        # hue: judged where the rarity colour is saturated enough for a hue to exist (common #9da5b4 has saturation 0.13)
                        hue_rows = [r for r in judged if r["targetSat"] >= 0.25]
                        bad_h = [(r["surface"], r["rarity"], r["hueErr_median"]) for r in hue_rows if r["hueErr_median"] >= args.hue_tol]
                        v.check("rings: hue error < %.0f deg on sand, grass and wood (rarities with a defined hue)" % args.hue_tol, not bad_h and len(hue_rows) >= 9,
                                {"judged": len(hue_rows), "over": bad_h})
                        com = [r for r in judged if r["targetSat"] < 0.25]
                        v.info("common ring (saturation 0.13: hue is not a meaningful gate) median hue error / chroma kept", [(r["surface"], r["hueErr_median"]) for r in com])
                        bad_l = [(r["surface"], r["rarity"], r["lumRatioHDR_median"]) for r in judged if r["lumRatioHDR_median"] < args.min_lum_ratio]
                        v.check("rings: >= %.1fx the floor luminance (scene-linear, pre-bloom, pre-tonemap) on sand, grass and wood" % args.min_lum_ratio, not bad_l,
                                {"judged": len(judged), "under": bad_l, "minRatio": min(r["lumRatioHDR_median"] for r in judged)})

            # ---- glare (information) ----------------------------------------------------------------------------------
            if want("glare"):
                spot = (spots or {}).get("grass")
                if spot:
                    G = []
                    for rar in range(5):
                        iid = "t_g_%d" % rar
                        s.js("([id, d, x, z]) => window.__LG__.spawn(id, d, x, z)", [iid, {"kind": "weapon", "id": "ar", "rarity": rar, "mag": 30}, spot["x"], spot["z"]])
                        rig.place(spot["x"], spot["z"], dist=7.0, pitch=0.10, yaw_off=0.30)
                        info = s.js("(id) => window.__LG__.info(id)", iid)
                        if not info or not info.get("beam"):
                            G.append({"rarity": RARITY_NAME[rar], "skipped": "no beam"})
                            continue
                        bx, by, bz = info["beam"]["x"], info["beam"]["y"], info["beam"]["z"]
                        top = info["beam"]["top"]
                        p0 = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [bx, by + 0.3, bz])
                        p1 = rig.js("([x, y, z]) => window.__LG__.project(x, y, z)", [bx, top - 0.1, bz])
                        W_, H_ = rig.size
                        x0 = int(p0[0]) - 24; rect = [max(0, x0), max(0, int(min(p0[1], p1[1])) - 6), 49, int(abs(p0[1] - p1[1])) + 12]
                        rect[3] = min(rect[3], H_ - rect[1])
                        rig.js("() => window.__LG__.vis(false, true, false)")
                        on = rig.grab(rect, True, True)
                        rig.js("() => window.__LG__.vis(false, false, false)")
                        of = rig.grab(rect, True, True)
                        rig.js("() => window.__LG__.vis(true, true, true)")
                        d = lum(on["hdr"][..., :3]) - lum(of["hdr"][..., :3])
                        bl = lambda a: 0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]  # noqa: E731  UnrealBloom's luminance weights
                        dd = bl(on["hdr"][..., :3]) - bl(of["hdr"][..., :3])
                        col = np.unravel_index(np.argmax(d), d.shape)[1]
                        axis = d[:, max(0, col - 1):col + 2].max(axis=1)
                        peak_row = int(np.argmax(axis))
                        bg = lum(of["hdr"][..., :3])[peak_row, max(0, col - 1):col + 2].mean()
                        peak_on = lum(on["hdr"][..., :3])[:, max(0, col - 1):col + 2].max()
                        width_core = int((d[peak_row] > 0.5 * d.max()).sum())
                        # halo: the displayed frame's brightening around the beam at the peak row, > 4/255 over the hidden frame
                        sd = np.abs(on["srgb"][peak_row, :, :3] - of["srgb"][peak_row, :, :3]).max(axis=-1)
                        width_halo = int((sd > 4).sum())
                        G.append({"rarity": RARITY_NAME[rar], "beamContribPeakLum": round(float(d.max()), 3), "bloomWeightedContribPeak": round(float(dd.max()), 3),
                                  "bgLum": round(float(bg), 3), "peakOverBg": round(float(peak_on / max(bg, 1e-3)), 2), "corePx": width_core, "haloPx": width_halo,
                                  "haloOverCore": round(width_halo / max(width_core, 1), 2)})
                        s.js("(id) => window.__LC__.W.netTakeItem(id)", iid)
                    v.data["glare"] = G
                    for g in G:
                        v.info("glare %s" % g.get("rarity"), g)
                    cu = [g for g in G if g.get("rarity") in ("common", "uncommon") and "bloomWeightedContribPeak" in g]
                    if cu:
                        v.check("glare: common / uncommon beam contribution stays under the 0.72 bloom threshold (bloom-weighted luminance of the beam's own radiance)",
                                all(g["bloomWeightedContribPeak"] < 0.72 for g in cu), [(g["rarity"], g["bloomWeightedContribPeak"]) for g in cu])
                else:
                    v.cnj("glare", "no grass spot")

            # ---- errors -----------------------------------------------------------------------------------------------
            d = s.diagnostics()
            mine = [t for t in d["shader"] if "Material Name: Loot" in t or "loot-" in t]
            other = [t for t in d["shader"] if t not in mine]
            v.check("errors: 0 page errors, 0 window errors, 0 console errors, 0 failed requests",
                    not (d["pageErrors"] or d["windowErrors"] or d["consoleErrors"] or d["failedRequests"]),
                    {k: d[k][:3] for k in ("pageErrors", "windowErrors", "consoleErrors", "failedRequests")})
            v.check("errors: 0 shader errors from the loot materials", not mine, {"mine": len(mine), "first": (mine[0][:300] if mine else None)})
            if other:
                names = sorted({(t.split("Material Name:")[1].split("\n")[0].strip() if "Material Name:" in t else t[:60]) for t in other})
                v.info("shader errors from OTHER lanes' materials (not gating this lane)", {"count": len(other), "materials": names})

    return C.run_gate("loot_beams_rings", body, args)


if __name__ == "__main__":
    sys.exit(main())
